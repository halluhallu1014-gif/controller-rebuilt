Attribute VB_Name = "Workflow"
Option Explicit

Private isOwnerSignedIn As Boolean
Private Const OWNER_PAGE As String = "�I�[�i�[��p"

Public Sub InstallWorkflow()
    Dim config As Worksheet
    Dim search As Worksheet
    Dim detail As Worksheet
    Dim owner As Worksheet
    Dim button As Shape
    Dim labels As Variant
    Dim i As Long

    Set config = Sheet("Settings")
    config.Range("S1").Value2 = "OwnerWindowsAccounts"
    config.Range("S4").Value2 = "S2: �I�[�i�[ / S3: �\��������ID"
    labels = Array("�R�s�[�����", "���ږ�", "����ID", "�ʒu", "��؂�", "���`�E����")
    For i = 0 To UBound(labels)
        config.Cells(1, 20 + i).Value2 = labels(i)
    Next
    If Len(CStr(config.Range("T2").Value2)) = 0 Then InstallImportDefaults config
    Sheet("Comparison").Range("F7").Value2 = "�D��x�i1�`5�j"
    Set search = Sheet("����")
    Set detail = Sheet("�ڍ�")
    For Each button In search.Shapes
        If button.OnAction Like "*ConfirmSaveResult" Or button.OnAction Like "*OpenOperations" Then button.Visible = msoFalse
    Next
    Set button = search.Shapes("ControllerCompare")
    button.OnAction = MacroAddress("ChooseComparisonSource")
    AddWorkflowButton search, "WorkflowExtract", "���o�E���", "OpenPendingReport", search.Range("S40:W41")
    detail.Shapes("UI_�R�s�[�捞").OnAction = MacroAddress("ImportMultipleFields")
    detail.Shapes("UI_�R�s�[�捞").TextFrame2.TextRange.text = "�������ڂ��捞"
    detail.Shapes("UI_�I�����ڂ֎捞").OnAction = MacroAddress("ImportOneField")
    detail.Shapes("UI_�I�����ڂ֎捞").TextFrame2.TextRange.text = "�I�𗓂֎捞"
    Set owner = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
    owner.name = OWNER_PAGE
    owner.Range("B2:J3").Merge
    owner.Range("B2").Value2 = "CONTROLLER / �I�[�i�[��p"
    owner.Range("B2:J3").Interior.Color = RGB(22, 44, 67)
    owner.Range("B2:J3").Font.Color = vbWhite
    owner.Range("B2:J3").Font.size = 17
    owner.Range("B5").Value2 = "��΂̊Ǘ��ɂ͏]���ǂ���S���敪�̌������K�v�ł��B"
    AddWorkflowButton owner, "WorkflowRecovery", "�ۑ����Ċm�F", "ConfirmSaveResult", owner.Range("B7:E8")
    AddWorkflowButton owner, "WorkflowOperations", "��΂̊Ǘ�", "OpenOperations", owner.Range("F7:I8")
    AddWorkflowButton owner, "WorkflowSignOut", "���O�A�E�g", "SignOutOwner", owner.Range("B10:E11")
    search.Activate
    owner.Visible = xlSheetVeryHidden
End Sub

Public Sub AddWorkflowButton(ByVal ws As Worksheet, ByVal id As String, ByVal caption As String, _
    ByVal action As String, ByVal position As Range)
    Dim button As Shape
    Set button = ws.Shapes.AddShape(msoShapeRoundedRectangle, position.left, position.Top, position.width, position.Height)
    button.name = id
    button.Fill.ForeColor.RGB = RGB(31, 96, 143)
    button.line.Visible = msoFalse
    button.TextFrame2.TextRange.text = caption
    button.TextFrame2.TextRange.Font.size = 11
    button.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = vbWhite
    button.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    button.TextFrame2.VerticalAnchor = msoAnchorMiddle
    button.OnAction = MacroAddress(action)
End Sub

Private Function CurrentOwnerListed() As Boolean
    Dim account As Variant
    Dim login As String
    login = Environ$("USERDOMAIN") & "\" & Environ$("USERNAME")
    If Len(Environ$("USERNAME")) = 0 Or Len(Environ$("USERDOMAIN")) = 0 Then Exit Function
    For Each account In Split(CStr(Sheet("Settings").Range("S2").Value2), ";")
        If StrComp(Trim$(CStr(account)), login, vbTextCompare) = 0 Then
            CurrentOwnerListed = True
            Exit Function
        End If
    Next
End Function

Public Function IsOwnerAuthorized() As Boolean
    If isOwnerSignedIn Then IsOwnerAuthorized = CurrentOwnerListed()
End Function

Public Sub OpenOwnerWorkspace()
    If Not CurrentOwnerListed() Then
        Notify "����Windows�A�J�E���g�̓I�[�i�[�Ƃ��ēo�^����Ă��܂���B"
        Exit Sub
    End If
    If Not UiCanLeaveDetail() Then Exit Sub
    If MsgBox("���݂�Windows�A�J�E���g�ŃI�[�i�[������J�n���܂����H", vbQuestion Or vbYesNo Or vbDefaultButton2) <> vbYes Then Exit Sub
    SignInWindowsOwner
End Sub

Public Function SignInWindowsOwner() As Boolean
    If Not CurrentOwnerListed() Then Exit Function
    isOwnerSignedIn = True
    Sheet(OWNER_PAGE).Visible = xlSheetVisible
    Sheet(OWNER_PAGE).Activate
    SignInWindowsOwner = True
End Function

Public Sub SignOutOwner()
    isOwnerSignedIn = False
    HideOwnerWorkspace
End Sub

Public Sub HideOwnerWorkspace()
    Dim ws As Worksheet
    Set ws = Sheet(OWNER_PAGE)
    If ws.Visible = xlSheetVeryHidden Then Exit Sub
    If ActiveSheet Is ws Then Sheet("����").Activate
    ws.Visible = xlSheetVeryHidden
End Sub


