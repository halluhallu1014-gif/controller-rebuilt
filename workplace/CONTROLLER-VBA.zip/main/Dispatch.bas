Attribute VB_Name = "Dispatch"
Option Explicit



Public Const DISPATCH_FIRST As Long = 69
Private Const DISPATCH_ROWS As Long = 2
Private shownDay(1 To 3) As Variant
Private shownTitle(1 To 3) As String
Private shownNote(1 To 3) As String
Private dispatchTitles As Object

Public Function IsDispatchField(ByVal id As String) As Boolean
    IsDispatchField = (id = "Dispatch1" Or id = "Dispatch2" Or id = "Dispatch3")
End Function

Public Sub InstallDispatchAreas()
    Dim ws As Worksheet
    Dim block As Long
    Dim row As Long
    Dim button As Shape
    Dim template As Shape
    Dim anchor As Range
    Dim wasProtected As Boolean
    Set ws = Sheet("�ڍ�")
    wasProtected = ws.ProtectContents
    If wasProtected Then ws.Unprotect
    ws.Rows("65:68").Hidden = True
    ws.columns("AZ").Hidden = True
    ws.Range("C69:V85").UnMerge
    ws.Range("C69:V85").Clear
    ws.Rows("69:75").Hidden = False
    ws.Rows("76:85").Hidden = True
    ws.Rows(69).RowHeight = 18
    DispatchBand ws.Range("C69:V69"), "��������", RGB(214, 229, 246), RGB(24, 48, 80)
    ws.Range("C69:V75").Font.name = "Meiryo UI"
    ws.Range("C69:V75").Font.size = 11
    Set template = ws.Shapes("Calendar_ReceivedDate")
    For block = 1 To 3
        row = DispatchRow(block)
        ws.Rows(row + 1).RowHeight = ws.Rows(32).RowHeight
        ws.Rows(row + 2).RowHeight = 16

        DispatchBand ws.Range("C" & row + 1 & ":D" & row + 1), "����" & block, RGB(214, 229, 246), RGB(24, 48, 80)
        DispatchBand ws.Cells(row + 1, 5), "������", RGB(214, 229, 246), RGB(24, 48, 80)
        ws.Cells(row + 1, 5).HorizontalAlignment = xlCenter
        DispatchBand ws.Range("M" & row + 1 & ":O" & row + 1), "������", RGB(214, 229, 246), RGB(24, 48, 80)
        DispatchBand ws.Range("C" & row + 2 & ":E" & row + 2), "���l", RGB(214, 229, 246), RGB(24, 48, 80)
        DispatchBox ws.Range("F" & row + 1 & ":K" & row + 1)
        DispatchBox ws.Range("P" & row + 1 & ":V" & row + 1)
        DispatchBox ws.Range("F" & row + 2 & ":V" & row + 2)
        ws.Cells(row + 1, 6).NumberFormat = ws.Range("F32").NumberFormat
        Set anchor = ws.Cells(row + 1, 12)
        Set button = Nothing
        On Error Resume Next
        Set button = ws.Shapes("Calendar_Dispatch" & block)
        On Error GoTo 0
        If button Is Nothing Then Set button = template.Duplicate
        button.name = "Calendar_Dispatch" & block
        button.left = anchor.left + (anchor.width - template.width) / 2
        button.Top = anchor.Top + (anchor.Height - template.Height) / 2
        button.width = template.width
        button.Height = template.Height
        button.Placement = xlMove
        button.OnAction = template.OnAction
    Next
    Set button = Nothing
    On Error Resume Next
    Set button = ws.Shapes("DispatchCalendar")
    On Error GoTo 0
    If Not button Is Nothing Then button.Delete
    Set button = Nothing
    On Error Resume Next
    Set button = ws.Shapes("DispatchSave")
    On Error GoTo 0

    ws.Rows(59).Hidden = False
    ws.Rows(59).RowHeight = 36
    Set anchor = ws.Range("R59:V59")
    If button Is Nothing Then
        AddWorkflowButton ws, "DispatchSave", "�o�^�E�X�V", "SaveDetail", anchor
        Set button = ws.Shapes("DispatchSave")
    End If
    button.width = anchor.width - 4
    button.Height = 26
    button.left = anchor.left + 2
    button.Top = anchor.Top + (anchor.Height - button.Height) / 2
    button.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    button.TextFrame2.VerticalAnchor = msoAnchorMiddle
    AlignCopyButtons ws
    If wasProtected Then ws.Protect DrawingObjects:=False, UserInterfaceOnly:=True
End Sub


Private Sub AlignCopyButtons(ByVal ws As Worksheet)
    Dim names As Variant
    Dim button As Shape
    Dim area As Range
    Dim width As Double
    Dim index As Long
    Const GAP As Double = 4
    names = Array("ControllerCopyNumber", "UI_�I�����ڂ��R�s�[", "UI_�R�s�[�捞", "UI_�I�����ڂ֎捞")
    Set area = ws.Range("C58:V58")
    width = (area.width - GAP * 5) / 4
    For index = 0 To UBound(names)
        Set button = ws.Shapes(CStr(names(index)))
        button.width = width
        button.left = area.left + GAP + index * (width + GAP)
        button.Top = area.Top + (area.Height - button.Height) / 2
    Next
End Sub

Private Sub DispatchBand(ByVal area As Range, ByVal caption As String, ByVal background As Long, ByVal ink As Long)
    area.Merge
    area.Cells(1, 1).Value2 = caption
    area.Interior.Color = background
    area.Font.Color = ink
    area.Font.Bold = True
    area.VerticalAlignment = xlCenter
End Sub

Private Sub DispatchBox(ByVal area As Range)
    area.Merge
    area.Interior.Color = vbWhite
    area.Font.Color = RGB(24, 48, 80)
    area.Borders.Color = RGB(190, 206, 225)
    area.HorizontalAlignment = xlLeft
    area.VerticalAlignment = xlCenter
End Sub

Private Function DispatchRow(ByVal block As Long) As Long
    DispatchRow = DISPATCH_FIRST + (block - 1) * DISPATCH_ROWS
End Function

Public Sub LoadDispatchAreas()
    Dim ws As Worksheet
    Dim candidates As Object
    Dim configured As Object
    Dim key As Variant
    Dim block As Long
    Dim row As Long
    Dim count As Long
    Dim title As String
    Dim raw As String
    Dim record As CaseRecord
    Set ws = Sheet("�ڍ�")
    Set configured = ConfiguredList(16)
    Set candidates = configured
    If configured.count = 0 Then
        Set candidates = NewDictionary()
        If Not Cases Is Nothing Then
            For Each key In Cases.Keys
                Set record = Cases(key)
                For block = 1 To 3
                    raw = CStr(record.values("Dispatch" & block))
                    title = DispatchKnownTitle(raw)
                    If Len(title) > 0 Then candidates(title) = True
                Next
            Next
        End If
    End If
    Set dispatchTitles = candidates
    ws.Range("AZ100:AZ599").ClearContents
    For Each key In candidates.Keys
        If count = 500 Then Exit For
        PutValue ws.Cells(100 + count, 52), CStr(key)
        count = count + 1
    Next
    For block = 1 To 3
        LoadDispatchArea block
        row = DispatchRow(block)
        With ws.Cells(row + 1, 16).Validation
            .Delete
            If count > 0 Then
                .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=$AZ$100:$AZ$" & 99 + count
                .InCellDropdown = True
                .IgnoreBlank = True
                .ShowError = False
            End If
        End With
    Next
End Sub

Public Sub LoadDispatchArea(ByVal block As Long)
    Dim ws As Worksheet
    Dim row As Long
    Dim original As Range
    Dim day As Variant
    Dim title As String
    Dim note As String
    Dim recognized As Boolean
    Set ws = Sheet("�ڍ�")
    row = DispatchRow(block)
    Set original = FieldCell("Dispatch" & block)
    day = ""
    If Not original.Locked Then
        recognized = ParseDispatch(CStr(original.Value2), day, title, note)
    End If
    ws.Cells(row + 2, 3).Value2 = "���l"
    If original.Locked Then
        ws.Cells(row + 2, 3).Value2 = "�ۑ��斢�ݒ�"
    ElseIf Not recognized Then
        ws.Cells(row + 2, 3).Value2 = "���l�i�����j"
    End If
    PutValue ws.Cells(row + 1, 6), day, True
    ws.Cells(row + 1, 6).NumberFormat = ws.Range("F32").NumberFormat
    PutValue ws.Cells(row + 1, 16), title
    PutValue ws.Cells(row + 2, 6), note
    ws.Cells(row + 1, 6).MergeArea.Locked = original.Locked
    ws.Cells(row + 1, 16).MergeArea.Locked = original.Locked
    ws.Cells(row + 2, 6).MergeArea.Locked = original.Locked
    shownDay(block) = day
    shownTitle(block) = title
    shownNote(block) = note
End Sub

Private Function DispatchKnownTitle(ByVal raw As String) As String
    Dim day As Variant
    Dim note As String
    Dim title As String
    If ParseDispatch(raw, day, title, note, False) Then DispatchKnownTitle = title
End Function

Private Function ParseDispatch(ByVal raw As String, ByRef day As Variant, ByRef title As String, _
    ByRef note As String, Optional ByVal allowTitleOnly As Boolean = True) As Boolean
    Dim text As String
    Dim header As String
    Dim tail As String
    Dim parts As Variant
    Dim position As Long
    Dim candidates As Object
    day = ""
    title = ""
    note = ""
    If Len(raw) = 0 Then
        ParseDispatch = True
        Exit Function
    End If
    text = Replace(Replace(raw, vbCrLf, vbLf), vbCr, vbLf)
    position = InStr(text, vbLf)
    header = text
    If position > 0 Then
        header = left$(text, position - 1)
        tail = Mid$(text, position + 1)
    End If
    If Len(header) = 0 Then
        note = tail
        ParseDispatch = True
        Exit Function
    End If
    If TryDispatchDate(left$(header, 10), day) Then
        Select Case Mid$(header, 11)
            Case ""
                note = tail
                ParseDispatch = True
            Case Else
                If Mid$(header, 11, 1) = ChrW(&H3000) Then
                    title = Mid$(header, 12)
                    note = tail
                    ParseDispatch = True
                ElseIf position = 0 Then
                    parts = Split(header, " / ")
                    If UBound(parts) = 2 Then
                        If Len(parts(0)) = 10 And Len(parts(1)) > 0 And Len(parts(2)) > 0 Then
                            title = CStr(parts(1))
                            note = "���₢���킹�ԍ��F" & parts(2)
                            ParseDispatch = True
                        End If
                    End If
                End If
        End Select
    ElseIf allowTitleOnly Then
        Set candidates = ConfiguredList(16)
        If candidates.Exists(header) Or DispatchListedOnSheet(header) Then
            title = header
            note = tail
            ParseDispatch = True
        End If
    End If
    If Not ParseDispatch Then
        day = ""
        note = raw
    End If
End Function

Private Function DispatchListedOnSheet(ByVal title As String) As Boolean
    If Not dispatchTitles Is Nothing Then DispatchListedOnSheet = dispatchTitles.Exists(title)
End Function

Private Function TryDispatchDate(ByVal text As String, ByRef serial As Variant) As Boolean
    Dim value As Date
    On Error GoTo Invalid
    If Not text Like "####/##/##" Then Exit Function
    value = DateSerial(CLng(left$(text, 4)), CLng(Mid$(text, 6, 2)), CLng(right$(text, 2)))
    If Format$(value, "yyyy/mm/dd") <> text Or CDbl(value) < 1 Then Exit Function
    serial = CDbl(value)
    TryDispatchDate = True
Invalid:
End Function

Public Function DispatchAreaChanged(ByVal id As String) As Boolean
    Dim block As Long
    Dim row As Long
    Dim ws As Worksheet
    If Not IsDispatchField(id) Then Exit Function
    block = CLng(right$(id, 1))
    row = DispatchRow(block)
    Set ws = Sheet("�ڍ�")
    DispatchAreaChanged = Not SameValue(ws.Cells(row + 1, 6).Value2, shownDay(block)) Or _
        Not SameValue(ws.Cells(row + 1, 16).Value2, shownTitle(block)) Or _
        Not SameValue(ws.Cells(row + 2, 6).Value2, shownNote(block))
End Function

Public Function ReadDispatchArea(ByVal id As String, ByRef value As Variant, ByRef message As String) As Boolean
    Dim ws As Worksheet
    Dim row As Long
    Dim day As Variant
    Dim title As Variant
    Dim note As Variant
    Dim normalized As Variant
    Dim header As String
    Set ws = Sheet("�ڍ�")
    If Not DispatchAreaChanged(id) Then
        value = FieldCell(id).Value2
        ReadDispatchArea = True
        Exit Function
    End If
    row = DispatchRow(CLng(right$(id, 1)))
    day = ws.Cells(row + 1, 6).Value2
    title = ws.Cells(row + 1, 16).Value2
    note = ws.Cells(row + 2, 6).Value2
    message = "��������" & right$(id, 1)
    If Not NormalizeValue("ApplicationDate", day, normalized) Then
        message = message & "�̔���������t�œ��͂��Ă��������B"
        Exit Function
    End If
    If IsError(title) Or IsError(note) Then
        message = message & "�ɓ��̓G���[������܂��B"
        Exit Function
    End If
    title = Trim$(CStr(title))
    If InStr(title, vbCr) > 0 Or InStr(title, vbLf) > 0 Then
        message = message & "�̕�������1�s�œ��͂��Ă��������B"
        Exit Function
    End If
    If Len(CStr(normalized)) > 0 Then header = Format$(CDate(normalized), "yyyy/mm/dd")
    If Len(header) > 0 And Len(title) > 0 Then header = header & ChrW(&H3000)
    header = header & title
    If Len(CStr(note)) > 0 Then header = header & vbLf & Replace(Replace(CStr(note), vbCrLf, vbLf), vbCr, vbLf)
    If Len(header) > 32767 Then
        message = message & "��Excel��1�Z���̕���������𒴂��Ă��܂��B"
        Exit Function
    End If
    value = header
    message = ""
    ReadDispatchArea = True
End Function

Public Sub CreateLedgerYear()
    Dim entry As Variant
    Dim name As Variant
    Dim address As String
    Dim message As String
    Dim book As Workbook
    Dim page As Worksheet
    Dim ws As Worksheet
    Dim item As Variant
    Dim col As Long
    On Error GoTo Failed
    If Not CanMoveLedger(message) Then GoTo Finished
    If Not IsOwnerAuthorized() Then
        message = "�N�x�V�[�g�̍쐬�ɂ̓I�[�i�[�F�؂��K�v�ł��B"
        GoTo Finished
    End If
    If PendingSave() Or Len(CStr(Sheet("MoveRecovery").Range("B1").Value2)) > 0 Then
        message = "���m��̕ۑ��܂��͈ړ�������܂��B��ɏƍ����Ă��������B"
        GoTo Finished
    End If
    entry = Application.InputBox("�쐬����N�x�𐼗�4���œ��͂��Ă��������B", "�N�x�ǉ�", Type:=2)
    If VarType(entry) = vbBoolean Then Exit Sub
    If Not IsDigits(entry, 4) Then Exit Sub
    address = LocateFixedLedger(message, True)
    If Len(address) = 0 Then GoTo Finished
    Set book = OpenLedger(address, False, message)
    If book Is Nothing Then GoTo Finished
    For Each ws In book.Worksheets
        If StrComp(ws.name, CStr(entry), vbTextCompare) = 0 Then
            message = "�����̔N�x�V�[�g������܂��B"
            GoTo Finished
        End If
    Next
    Set page = book.Worksheets.Add(after:=book.Worksheets(book.Worksheets.count))
    page.name = CStr(entry)
    For Each item In LedgerColumnDefinitions()
        col = col + 1
        page.Cells(1, col).Value2 = item(1)
        page.columns(col).NumberFormat = IIf(item(2) = "Date", "yyyy/mm/dd", "@")
    Next
    book.Save
    If Not book.Saved Then GoTo Failed
    book.Close False
    Set book = OpenLedger(address, True, message)
    If book Is Nothing Then GoTo Failed
    Set page = book.Worksheets(CStr(entry))
    If CStr(page.Range("A1").Value2) <> "���ʔԍ�" Then GoTo Failed
    message = "�N�x�V�[�g���쐬���܂����B�ݒ�c�[���ŔN�x�E�V�[�g��o�^���Ă��������B"
Finished:
    If Not book Is Nothing Then book.Close False
    If Len(message) > 0 Then Notify message
    Exit Sub
Failed:
    message = "�N�x�쐬�̌��ʂ��m�F�ł��܂���B�Ǘ�����J���ĔN�x�V�[�g���m�F���Ă��瑀�삵�Ă��������B"
    Resume Finished
End Sub

Public Sub ArchiveLedgerYear()
    Dim year As Variant
    Dim filename As Variant
    Dim address As String
    Dim message As String
    Dim source As Workbook
    Dim archive As Workbook
    On Error GoTo Failed
    If Not IsOwnerAuthorized() Or Not CanMoveLedger(message) Then
        message = "�N�x�ۊǂɂ̓I�[�i�[�F�؂Ə�΃t�H���_����̋N�����K�v�ł��B"
        GoTo Finished
    End If
    year = Application.InputBox("�o�^�ς݂̔N�x����͂��Ă��������B", "�N�x�̕ۊ�", Type:=2)
    If VarType(year) = vbBoolean Then Exit Sub
    If Not LoadConfiguration(message) Then GoTo Finished
    If Not years.Exists(CStr(year)) Then
        message = "�Ώ۔N�x������܂���B"
        GoTo Finished
    End If
    filename = Application.InputBox("�ۊǐ�̖��g�p�̒���URL����͂��Ă��������B�t�@�C�����́u�ۊ�_�v�Ŏn�߁A.xlsx�ɂ��Ă��������B", "�N�x�̕ۊ�", Type:=2)
    If VarType(filename) = vbBoolean Then Exit Sub
    If Not IsDirectWorkbookAddress(CStr(filename)) Or Not IsHttpsAddress(CStr(filename)) Then Exit Sub
    If left$(AddressFileName(CStr(filename)), 3) <> "�ۊ�_" Or LCase$(right$(CStr(filename), 5)) <> ".xlsx" Then Exit Sub
    Dim target As Object
    Set target = FileState(CStr(filename), message)
    If target Is Nothing Then GoTo Finished
    If target("Exists") Then
        message = "�ۊǐ悪���łɑ��݂��܂��B�㏑�����܂���B"
        GoTo Finished
    End If
    address = ResolveYearAddress(CStr(year), message)
    If Len(address) = 0 Then GoTo Finished
    Set source = OpenLedger(address, True, message)
    If source Is Nothing Then GoTo Finished
    Dim book As Workbook
    Set archive = Workbooks.Add(xlWBATWorksheet)
    source.Worksheets(years(CStr(year))(1)).Copy before:=archive.Worksheets(1)
    archive.SaveAs CStr(filename), xlOpenXMLWorkbook
    message = "�N�x�V�[�g��ۊǂ��܂����B�����ȍX�V��͕ς��܂���B"
Finished:
    If Not archive Is Nothing Then archive.Close False
    If Not source Is Nothing Then source.Close False
    If Len(message) > 0 Then Notify message
    Exit Sub
Failed:
    message = "�ۊǌ��ʂ��m�F�ł��܂���B�ۑ�����J���Ċm�F���Ă��������B"
    Resume Finished
End Sub


