Attribute VB_Name = "Dispatch"
Option Explicit



Private Const DISPATCH_FIRST As Long = 53
Private shownDay(1 To 3) As Variant
Private shownTitle(1 To 3) As String
Private shownNote(1 To 3) As String
Private dispatchTitles As Object

Public Function IsDispatchField(ByVal id As String) As Boolean
    IsDispatchField = (id = "Dispatch1" Or id = "Dispatch2" Or id = "Dispatch3")
End Function

Public Sub InstallDispatchAreas()
    Dim ws As Worksheet
    Dim block As Long
    Dim row As Long
    Dim button As Shape
    Dim template As Shape
    Dim anchor As Range
    Dim wasProtected As Boolean
    Dim navy As Long
    Dim blue As Long

    Set ws = Sheet("�ڍ�")
    wasProtected = ws.ProtectContents
    If wasProtected Then ws.Unprotect
    AlignDetailGrid ws
    navy = RGB(24, 48, 80)
    blue = RGB(214, 229, 246)
    ws.Range("C49:V59").UnMerge
    ws.Range("C49:V59").Clear
    ws.Range("C69:V85").UnMerge
    ws.Range("C69:V85").Clear
    ws.Rows("49:59").Hidden = False
    ws.Rows("60:85").Hidden = True
    ws.columns("AZ").Hidden = True
    ws.Range("C49:V59").Font.name = "Meiryo UI"
    ws.Range("C49:V59").Font.size = 11
    ws.Range("C49:V55").Interior.Color = RGB(239, 245, 251)
    ws.Range("C49:L55").BorderAround Color:=RGB(155, 183, 213)
    ws.Range("N49:V55").BorderAround Color:=RGB(155, 183, 213)
    ws.Rows("53:55").RowHeight = 30
    ws.Rows(56).RowHeight = 8
    ws.Rows(57).RowHeight = 18
    ws.Rows(58).RowHeight = 33
    ws.Rows(59).RowHeight = 5
    Set template = ws.Shapes("Calendar_ReceivedDate")
    For block = 1 To 3
        row = DispatchRow(block)
        DispatchBand ws.Cells(row, 14), CStr(block), blue, navy
        ws.Cells(row, 14).HorizontalAlignment = xlRight
        DispatchBox ws.Range("O" & row & ":P" & row)
        DispatchBox ws.Range("R" & row & ":T" & row)
        DispatchBox ws.Range("U" & row & ":V" & row)
        ws.Cells(row, 15).NumberFormat = ws.Range("F32").NumberFormat
        ws.Cells(row, 21).WrapText = True
        Set anchor = ws.Cells(row, 17)
        Set button = LayoutShape(ws, "Calendar_Dispatch" & block)
        If button Is Nothing Then Set button = template.Duplicate
        button.name = "Calendar_Dispatch" & block
        button.width = template.width
        button.Height = template.Height
        button.left = anchor.left + (anchor.width - button.width) / 2
        button.Top = anchor.Top + (anchor.Height - button.Height) / 2
        button.Placement = xlMove
        button.OnAction = template.OnAction
    Next

    Set button = LayoutShape(ws, "DispatchCalendar")
    If Not button Is Nothing Then button.Delete
    Set button = LayoutShape(ws, "UI_�o�^�X�V")
    If Not button Is Nothing Then button.Visible = msoFalse
    InstallMemoLayout
    InstallDetailActions
    If wasProtected Then ws.Protect DrawingObjects:=False, UserInterfaceOnly:=True
End Sub

Public Sub InstallMemoLayout()
    Dim ws As Worksheet
    Dim row As Long
    Dim block As Long
    Dim ink As Long
    Dim blue As Long
    Dim wasProtected As Boolean
    Dim fieldRow As Long
    Dim fieldId As String

    Set ws = Sheet("�ڍ�")
    wasProtected = ws.ProtectContents
    If wasProtected Then ws.Unprotect
    ink = RGB(24, 48, 80)
    blue = RGB(214, 229, 246)
    ws.Range("C49:L52").UnMerge
    ws.Range("N49:V52").UnMerge
    ws.Range("C49:V52").ClearContents
    ws.Rows("50:52").Hidden = True
    ws.Rows(49).RowHeight = 22
    DispatchBand ws.Range("C49:L49"), "����", blue, ink
    DispatchBand ws.Range("N49"), "No.", blue, ink
    DispatchBand ws.Range("O49:Q49"), "���������E������", blue, ink
    DispatchBand ws.Range("R49:T49"), "������", blue, ink
    DispatchBand ws.Range("U49:V49"), "���l", blue, ink
    ws.Range("N49:V49").HorizontalAlignment = xlCenter
    ws.Range("O49").HorizontalAlignment = xlLeft
    ws.Range("O49").IndentLevel = 0
    ws.Range("O49").Font.size = 10
    ws.Range("C49:V49").VerticalAlignment = xlCenter
    For block = 1 To 3
        row = DispatchRow(block)
        fieldId = "Memo" & block
        With Sheet("Fields")
            For fieldRow = 2 To LastRow(Sheet("Fields"))
                If CStr(.Cells(fieldRow, 1).Value2) = fieldId Then Exit For
            Next
            If CStr(.Cells(fieldRow, 5).Value2) = "F" & row Then MoveDetailField fieldId, "F" & row, "D" & row
            If CStr(.Cells(fieldRow, 5).Value2) = "E" & row Then MoveDetailField fieldId, "E" & row, "D" & row
        End With
        Dim draft As Variant
        draft = FirstMemoValue(ws, row)
        ws.Range("C" & row & ":L" & row).UnMerge
        ws.Range("C" & row & ":L" & row).ClearContents
        DispatchBand ws.Cells(row, 3), CStr(block), blue, ink
        ws.Cells(row, 3).HorizontalAlignment = xlRight
        DispatchBox ws.Range("D" & row & ":L" & row)
        ws.Cells(row, 4).Font.Bold = False
        ws.Cells(row, 4).WrapText = True
        PutValue ws.Cells(row, 4), draft
    Next
    ws.Range("C49:L55").BorderAround Color:=RGB(155, 183, 213)
    ws.Range("N49:V55").BorderAround Color:=RGB(155, 183, 213)
    If wasProtected Then ws.Protect DrawingObjects:=False, UserInterfaceOnly:=True
End Sub

Private Function FirstMemoValue(ByVal ws As Worksheet, ByVal row As Long) As Variant
    Dim column As Long
    For column = 4 To 6
        If Not IsEmpty(ws.Cells(row, column).Value2) Then
            FirstMemoValue = ws.Cells(row, column).Value2
            Exit Function
        End If
    Next
End Function

Public Sub InstallDetailActions()
    Const GAP As Double = 5
    Const BUTTON_HEIGHT As Double = 26
    Dim ws As Worksheet
    Dim area As Range
    Dim buttonRow As Range
    Dim button As Shape
    Dim heading As Shape
    Dim names As Variant
    Dim headings As Variant
    Dim index As Long
    Dim width As Double
    Dim wasProtected As Boolean

    Set ws = Sheet("�ڍ�")
    wasProtected = ws.ProtectContents
    If wasProtected Then ws.Unprotect
    Set area = ws.Range("C57:V59")
    Set buttonRow = ws.Range("C58:V58")
    area.UnMerge
    area.Clear
    area.Interior.Color = RGB(249, 251, 253)
    area.BorderAround Color:=RGB(155, 183, 213)
    names = Array("DispatchSave", "UI_�o�^�X�V", "DetailCopyHeading", "DetailImportHeading")
    For index = 0 To UBound(names)
        Set button = LayoutShape(ws, CStr(names(index)))
        If Not button Is Nothing Then button.Delete
    Next

    headings = Array("�R�s�[", "�捞")
    names = Array("DetailCopyHeading", "DetailImportHeading")
    width = (area.width - 3 * GAP) / 2
    For index = 0 To UBound(names)
        Set heading = ws.Shapes.AddShape(msoShapeRectangle, area.left + GAP + index * (width + GAP), _
            area.Top, width, ws.Rows(57).Height)
        heading.name = CStr(names(index))
        heading.Fill.ForeColor.RGB = RGB(214, 229, 246)
        heading.line.Visible = msoFalse
        With heading.TextFrame2
            .VerticalAnchor = msoAnchorMiddle
            .MarginLeft = GAP
            .MarginRight = GAP
            .TextRange.text = CStr(headings(index))
            .TextRange.Font.name = "Meiryo UI"
            .TextRange.Font.size = 11
            .TextRange.Font.Bold = msoTrue
            .TextRange.Font.Fill.ForeColor.RGB = RGB(24, 48, 80)
        End With
    Next

    names = Array("ControllerCopyNumber", "UI_�I�����ڂ��R�s�[", "UI_�R�s�[�捞", "UI_�I�����ڂ֎捞")
    width = (area.width - 5 * GAP) / 4
    For index = 0 To UBound(names)
        Set button = ws.Shapes(CStr(names(index)))
        button.Placement = xlFreeFloating
        button.width = width
        button.Height = BUTTON_HEIGHT
        button.left = area.left + GAP + index * (width + GAP)
        button.Top = buttonRow.Top + (buttonRow.Height - BUTTON_HEIGHT) / 2
        With button.TextFrame2
            .TextRange.ParagraphFormat.Alignment = msoAlignCenter
            .VerticalAnchor = msoAnchorMiddle
            .TextRange.Font.name = "Meiryo UI"
            .TextRange.Font.size = 11
            .TextRange.Font.Bold = msoTrue
        End With
    Next
    If wasProtected Then ws.Protect DrawingObjects:=False, UserInterfaceOnly:=True
End Sub

Private Sub AlignDetailGrid(ByVal ws As Worksheet)
    Dim leftWidth As Double
    Dim blue As Long
    Dim ink As Long
    Dim button As Shape
    Dim anchor As Range
    Dim names As Variant
    Dim columns As Variant
    Dim index As Long
    blue = RGB(214, 229, 246)
    ink = RGB(24, 48, 80)

    ' Keep the existing field anchors for sections 01 and 02.
    ' Make the right input span match the complete left input span.
    leftWidth = ws.Range("F12:L12").width
    SetLayoutWidth ws.columns("V"), leftWidth - ws.Range("Q12:U12").width

    ws.Range("N38:V39").UnMerge
    ws.Range("N38:V39").Clear
    ws.Range("N41:V41").UnMerge
    ws.Range("N41:V41").Clear
    ws.Range("N41:V41").Interior.Color = ws.Range("M41").Interior.Color
    ws.Range("C44:V47").UnMerge
    ws.Range("C44:V47").Clear
    ws.Rows("44:45").Hidden = False
    ws.Rows(44).RowHeight = ws.Rows(40).RowHeight
    ws.Rows(45).RowHeight = ws.Rows(43).RowHeight
    ws.Rows("46:47").Hidden = True
    ws.Range("M45:V45").Interior.Color = ws.Range("M41").Interior.Color
    DispatchBand ws.Range("C45:E45"), "���ٓ�", blue, ink
    DispatchBox ws.Range("F45:K45")
    DispatchBand ws.Range("N38:P39"), "�₢���킹�ԍ�", blue, ink
    DispatchBox ws.Range("Q38:V39")
    AlignDetailLabelsCore ws
    MoveDetailField "ApprovedDate", "Q38", "F45"
    MoveDetailField "InquiryNumber", "Q41", "Q38"

    Set button = ws.Shapes("Calendar_ApprovedDate")
    Set anchor = ws.Range("L45")
    button.left = anchor.left + anchor.width - button.width
    button.Top = anchor.Top + (anchor.Height - button.Height) / 2
    button.Placement = xlMove

    names = Array("UI_�����֖߂�", "UI_�V�K�o�^", "UI_�X�V�ۑ�")
    columns = Array("N11:P11", "Q11:S11", "T11:W11")
    For index = 0 To UBound(names)
        Set button = ws.Shapes(CStr(names(index)))
        Set anchor = ws.Range(CStr(columns(index)))
        button.width = anchor.width - 6
        button.Height = ws.Range("C11").Height - 6
        button.left = anchor.left + 3
        button.Top = anchor.Top + 3
        If index > 0 Then button.Fill.ForeColor.RGB = ink
    Next
End Sub

Public Sub AlignDetailLabels()
    Dim ws As Worksheet
    Dim wasProtected As Boolean
    Set ws = Sheet("�ڍ�")
    wasProtected = ws.ProtectContents
    If wasProtected Then ws.Unprotect
    AlignDetailLabelsCore ws
    If wasProtected Then ws.Protect DrawingObjects:=False, UserInterfaceOnly:=True
End Sub

Private Sub AlignDetailLabelsCore(ByVal ws As Worksheet)
    AlignBasicInformation ws
    MatchDetailText ws.Range("N38").MergeArea, ws.Range("N36")
    MatchDetailText ws.Range("Q38").MergeArea, ws.Range("Q36")
    ws.Range("C44:V44").Interior.Color = ws.Range("C42").Interior.Color
    MatchDetailText ws.Range("C45").MergeArea, ws.Range("C43")
    MatchDetailText ws.Range("F45").MergeArea, ws.Range("F43")
    ws.Range("F45").MergeArea.NumberFormat = ws.Range("F43").NumberFormat
    ws.Range("L45").Interior.Color = ws.Range("L43").Interior.Color
End Sub

Private Sub AlignBasicInformation(ByVal ws As Worksheet)
    Dim postalValue As Variant
    If CStr(ws.Range("N17").Value2) <> "�X�֔ԍ�" Then
        postalValue = ws.Range("Q23").Value2
        ws.Range("N20:V21").Copy destination:=ws.Range("N17:V18")
        ws.Range("N17").Value2 = "�X�֔ԍ�"
        ws.Range("Q17").MergeArea.NumberFormat = "@"
        ws.Range("Q17").MergeArea.Locked = ws.Range("Q23").Locked
        ws.Range("Q17").Value2 = postalValue
        With ws.Range("N23:V23")
            .ClearContents
            .Interior.Color = ws.Range("M23").Interior.Color
            .Borders.LineStyle = xlNone
            .Locked = True
        End With
    End If
    MoveDetailField "PostalCode", "Q23", "Q17"
End Sub

Private Sub MatchDetailText(ByVal target As Range, ByVal example As Range)
    target.Font.name = example.Font.name
    target.Font.size = example.Font.size
    target.Font.Color = example.Font.Color
    target.Font.Bold = example.Font.Bold
    target.Interior.Color = example.Interior.Color
    target.HorizontalAlignment = example.HorizontalAlignment
    target.IndentLevel = example.IndentLevel
    target.VerticalAlignment = example.VerticalAlignment
End Sub

Private Sub SetLayoutWidth(ByVal column As Range, ByVal target As Double)
    Dim minimum As Double
    Dim maximum As Double
    Dim index As Long
    maximum = 60
    For index = 1 To 16
        column.ColumnWidth = (minimum + maximum) / 2
        If column.width < target Then
            minimum = column.ColumnWidth
        Else
            maximum = column.ColumnWidth
        End If
    Next
End Sub

Private Sub MoveDetailField(ByVal id As String, ByVal oldAddress As String, ByVal newAddress As String)
    Dim ws As Worksheet
    Dim row As Long
    Set ws = Sheet("Fields")
    For row = 2 To LastRow(ws)
        If CStr(ws.Cells(row, 1).Value2) = id Then
            If CStr(ws.Cells(row, 5).Value2) = oldAddress Then ws.Cells(row, 5).Value2 = newAddress
            If CStr(ws.Cells(row, 5).Value2) <> newAddress Then Err.Raise 5, , "��ʈʒu��ύX�ς݂̍��ڂł��F" & id
            Exit Sub
        End If
    Next
End Sub

Private Function LayoutShape(ByVal ws As Worksheet, ByVal name As String) As Shape
    On Error Resume Next
    Set LayoutShape = ws.Shapes(name)
    On Error GoTo 0
End Function

Private Sub DispatchBand(ByVal area As Range, ByVal caption As String, ByVal background As Long, ByVal ink As Long)
    area.Merge
    area.Cells(1, 1).Value2 = caption
    area.Interior.Color = background
    area.Font.Color = ink
    area.Font.Bold = True
    area.VerticalAlignment = xlCenter
End Sub

Private Sub DispatchBox(ByVal area As Range)
    area.Merge
    area.Interior.Color = vbWhite
    area.Font.Color = RGB(24, 48, 80)
    area.Borders.Color = RGB(190, 206, 225)
    area.HorizontalAlignment = xlLeft
    area.VerticalAlignment = xlCenter
End Sub

Private Function DispatchRow(ByVal block As Long) As Long
    DispatchRow = DISPATCH_FIRST + block - 1
End Function

Public Sub LoadDispatchAreas()
    Dim ws As Worksheet
    Dim candidates As Object
    Dim configured As Object
    Dim key As Variant
    Dim block As Long
    Dim row As Long
    Dim count As Long
    Dim title As String
    Dim raw As String
    Dim record As CaseRecord
    Set ws = Sheet("�ڍ�")
    Set configured = ConfiguredList(16)
    Set candidates = configured
    If configured.count = 0 Then
        Set candidates = NewDictionary()
        If Not Cases Is Nothing Then
            For Each key In Cases.Keys
                Set record = Cases(key)
                For block = 1 To 3
                    raw = CStr(record.values("Dispatch" & block))
                    title = DispatchKnownTitle(raw)
                    If Len(title) > 0 Then candidates(title) = True
                Next
            Next
        End If
    End If
    Set dispatchTitles = candidates
    ws.Range("AZ100:AZ599").ClearContents
    For Each key In candidates.Keys
        If count = 500 Then Exit For
        PutValue ws.Cells(100 + count, 52), CStr(key)
        count = count + 1
    Next
    For block = 1 To 3
        LoadDispatchArea block
        row = DispatchRow(block)
        With ws.Cells(row, 18).Validation
            .Delete
            If count > 0 Then
                .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=$AZ$100:$AZ$" & 99 + count
                .InCellDropdown = True
                .IgnoreBlank = True
                .ShowError = False
            End If
        End With
    Next
End Sub

Public Sub LoadDispatchArea(ByVal block As Long)
    Dim ws As Worksheet
    Dim row As Long
    Dim original As Range
    Dim day As Variant
    Dim title As String
    Dim note As String
    Dim recognized As Boolean
    Set ws = Sheet("�ڍ�")
    row = DispatchRow(block)
    Set original = FieldCell("Dispatch" & block)
    day = ""
    If Not original.Locked Then
        recognized = ParseDispatch(CStr(original.Value2), day, title, note)
    End If
    ws.Cells(row, 14).Value2 = CStr(block)
    If original.Locked Then
        ws.Cells(row, 14).Value2 = CStr(block) & " ��"
    ElseIf Not recognized Then
        ws.Cells(row, 14).Value2 = CStr(block) & " ��"
    End If
    PutValue ws.Cells(row, 15), day, True
    ws.Cells(row, 15).NumberFormat = ws.Range("F32").NumberFormat
    PutValue ws.Cells(row, 18), title
    PutValue ws.Cells(row, 21), note
    ws.Cells(row, 15).MergeArea.Locked = original.Locked
    ws.Cells(row, 18).MergeArea.Locked = original.Locked
    ws.Cells(row, 21).MergeArea.Locked = original.Locked
    shownDay(block) = day
    shownTitle(block) = title
    shownNote(block) = note
End Sub

Private Function DispatchKnownTitle(ByVal raw As String) As String
    Dim day As Variant
    Dim note As String
    Dim title As String
    If ParseDispatch(raw, day, title, note, False) Then DispatchKnownTitle = title
End Function

Private Function ParseDispatch(ByVal raw As String, ByRef day As Variant, ByRef title As String, _
    ByRef note As String, Optional ByVal allowTitleOnly As Boolean = True) As Boolean
    Dim text As String
    Dim header As String
    Dim tail As String
    Dim parts As Variant
    Dim position As Long
    Dim candidates As Object
    day = ""
    title = ""
    note = ""
    If Len(raw) = 0 Then
        ParseDispatch = True
        Exit Function
    End If
    text = Replace(Replace(raw, vbCrLf, vbLf), vbCr, vbLf)
    position = InStr(text, vbLf)
    header = text
    If position > 0 Then
        header = left$(text, position - 1)
        tail = Mid$(text, position + 1)
    End If
    If Len(header) = 0 Then
        note = tail
        ParseDispatch = True
        Exit Function
    End If
    If TryDispatchDate(left$(header, 10), day) Then
        Select Case Mid$(header, 11)
            Case ""
                note = tail
                ParseDispatch = True
            Case Else
                If Mid$(header, 11, 1) = ChrW(&H3000) Then
                    title = Mid$(header, 12)
                    note = tail
                    ParseDispatch = True
                ElseIf position = 0 Then
                    parts = Split(header, " / ")
                    If UBound(parts) = 2 Then
                        If Len(parts(0)) = 10 And Len(parts(1)) > 0 And Len(parts(2)) > 0 Then
                            title = CStr(parts(1))
                            note = "���₢���킹�ԍ��F" & parts(2)
                            ParseDispatch = True
                        End If
                    End If
                End If
        End Select
    ElseIf allowTitleOnly Then
        Set candidates = ConfiguredList(16)
        If candidates.Exists(header) Or DispatchListedOnSheet(header) Then
            title = header
            note = tail
            ParseDispatch = True
        End If
    End If
    If Not ParseDispatch Then
        day = ""
        note = raw
    End If
End Function

Private Function DispatchListedOnSheet(ByVal title As String) As Boolean
    If Not dispatchTitles Is Nothing Then DispatchListedOnSheet = dispatchTitles.Exists(title)
End Function

Private Function TryDispatchDate(ByVal text As String, ByRef serial As Variant) As Boolean
    Dim value As Date
    On Error GoTo Invalid
    If Not text Like "####/##/##" Then Exit Function
    value = DateSerial(CLng(left$(text, 4)), CLng(Mid$(text, 6, 2)), CLng(right$(text, 2)))
    If Format$(value, "yyyy/mm/dd") <> text Or CDbl(value) < 1 Then Exit Function
    serial = CDbl(value)
    TryDispatchDate = True
Invalid:
End Function

Public Function DispatchAreaChanged(ByVal id As String) As Boolean
    Dim block As Long
    Dim row As Long
    Dim ws As Worksheet
    If Not IsDispatchField(id) Then Exit Function
    block = CLng(right$(id, 1))
    row = DispatchRow(block)
    Set ws = Sheet("�ڍ�")
    DispatchAreaChanged = Not SameValue(ws.Cells(row, 15).Value2, shownDay(block)) Or _
        Not SameValue(ws.Cells(row, 18).Value2, shownTitle(block)) Or _
        Not SameValue(ws.Cells(row, 21).Value2, shownNote(block))
End Function

Public Function ReadDispatchArea(ByVal id As String, ByRef value As Variant, ByRef message As String) As Boolean
    Dim ws As Worksheet
    Dim row As Long
    Dim day As Variant
    Dim title As Variant
    Dim note As Variant
    Dim normalized As Variant
    Dim header As String
    Set ws = Sheet("�ڍ�")
    If Not DispatchAreaChanged(id) Then
        value = FieldCell(id).Value2
        ReadDispatchArea = True
        Exit Function
    End If
    row = DispatchRow(CLng(right$(id, 1)))
    day = ws.Cells(row, 15).Value2
    title = ws.Cells(row, 18).Value2
    note = ws.Cells(row, 21).Value2
    message = "��������" & right$(id, 1)
    If Not NormalizeValue("ApplicationDate", day, normalized) Then
        message = message & "�̔���������t�œ��͂��Ă��������B"
        Exit Function
    End If
    If IsError(title) Or IsError(note) Then
        message = message & "�ɓ��̓G���[������܂��B"
        Exit Function
    End If
    title = Trim$(CStr(title))
    If InStr(title, vbCr) > 0 Or InStr(title, vbLf) > 0 Then
        message = message & "�̕�������1�s�œ��͂��Ă��������B"
        Exit Function
    End If
    If Len(CStr(normalized)) > 0 Then header = Format$(CDate(normalized), "yyyy/mm/dd")
    If Len(header) > 0 And Len(title) > 0 Then header = header & ChrW(&H3000)
    header = header & title
    If Len(CStr(note)) > 0 Then header = header & vbLf & Replace(Replace(CStr(note), vbCrLf, vbLf), vbCr, vbLf)
    If Len(header) > 32767 Then
        message = message & "��Excel��1�Z���̕���������𒴂��Ă��܂��B"
        Exit Function
    End If
    value = header
    message = ""
    ReadDispatchArea = True
End Function

Public Sub CreateLedgerYear()
    Dim entry As Variant
    Dim name As Variant
    Dim address As String
    Dim message As String
    Dim book As Workbook
    Dim page As Worksheet
    Dim ws As Worksheet
    Dim item As Variant
    Dim col As Long
    On Error GoTo Failed
    If Not CanMoveLedger(message) Then GoTo Finished
    If Not IsOwnerAuthorized() Then
        message = "�N�x�V�[�g�̍쐬�ɂ̓I�[�i�[�F�؂��K�v�ł��B"
        GoTo Finished
    End If
    If PendingSave() Or Len(CStr(Sheet("MoveRecovery").Range("B1").Value2)) > 0 Then
        message = "���m��̕ۑ��܂��͈ړ�������܂��B��ɏƍ����Ă��������B"
        GoTo Finished
    End If
    entry = Application.InputBox("�쐬����N�x�𐼗�4���œ��͂��Ă��������B", "�N�x�ǉ�", Type:=2)
    If VarType(entry) = vbBoolean Then Exit Sub
    If Not IsDigits(entry, 4) Then Exit Sub
    address = LocateFixedLedger(message, True)
    If Len(address) = 0 Then GoTo Finished
    Set book = OpenLedger(address, False, message)
    If book Is Nothing Then GoTo Finished
    For Each ws In book.Worksheets
        If StrComp(ws.name, CStr(entry), vbTextCompare) = 0 Then
            message = "�����̔N�x�V�[�g������܂��B"
            GoTo Finished
        End If
    Next
    Set page = book.Worksheets.Add(after:=book.Worksheets(book.Worksheets.count))
    page.name = CStr(entry)
    For Each item In LedgerColumnDefinitions()
        col = col + 1
        page.Cells(1, col).Value2 = item(1)
        page.columns(col).NumberFormat = IIf(item(2) = "Date", "yyyy/mm/dd", "@")
    Next
    book.Save
    If Not book.Saved Then GoTo Failed
    book.Close False
    Set book = OpenLedger(address, True, message)
    If book Is Nothing Then GoTo Failed
    Set page = book.Worksheets(CStr(entry))
    If CStr(page.Range("A1").Value2) <> "���ʔԍ�" Then GoTo Failed
    message = "�N�x�V�[�g���쐬���܂����B�ݒ�c�[���ŔN�x�E�V�[�g��o�^���Ă��������B"
Finished:
    If Not book Is Nothing Then book.Close False
    If Len(message) > 0 Then Notify message
    Exit Sub
Failed:
    message = "�N�x�쐬�̌��ʂ��m�F�ł��܂���B�Ǘ�����J���ĔN�x�V�[�g���m�F���Ă��瑀�삵�Ă��������B"
    Resume Finished
End Sub

Public Sub ArchiveLedgerYear()
    Dim year As Variant
    Dim filename As Variant
    Dim address As String
    Dim message As String
    Dim source As Workbook
    Dim archive As Workbook
    On Error GoTo Failed
    If Not IsOwnerAuthorized() Or Not CanMoveLedger(message) Then
        message = "�N�x�ۊǂɂ̓I�[�i�[�F�؂Ə�΃t�H���_����̋N�����K�v�ł��B"
        GoTo Finished
    End If
    year = Application.InputBox("�o�^�ς݂̔N�x����͂��Ă��������B", "�N�x�̕ۊ�", Type:=2)
    If VarType(year) = vbBoolean Then Exit Sub
    If Not LoadConfiguration(message) Then GoTo Finished
    If Not years.Exists(CStr(year)) Then
        message = "�Ώ۔N�x������܂���B"
        GoTo Finished
    End If
    filename = Application.InputBox("�ۊǐ�̖��g�p�̒���URL����͂��Ă��������B�t�@�C�����́u�ۊ�_�v�Ŏn�߁A.xlsx�ɂ��Ă��������B", "�N�x�̕ۊ�", Type:=2)
    If VarType(filename) = vbBoolean Then Exit Sub
    If Not IsDirectWorkbookAddress(CStr(filename)) Or Not IsHttpsAddress(CStr(filename)) Then Exit Sub
    If left$(AddressFileName(CStr(filename)), 3) <> "�ۊ�_" Or LCase$(right$(CStr(filename), 5)) <> ".xlsx" Then Exit Sub
    Dim target As Object
    Set target = FileState(CStr(filename), message)
    If target Is Nothing Then GoTo Finished
    If target("Exists") Then
        message = "�ۊǐ悪���łɑ��݂��܂��B�㏑�����܂���B"
        GoTo Finished
    End If
    address = ResolveYearAddress(CStr(year), message)
    If Len(address) = 0 Then GoTo Finished
    Set source = OpenLedger(address, True, message)
    If source Is Nothing Then GoTo Finished
    Dim book As Workbook
    Set archive = Workbooks.Add(xlWBATWorksheet)
    source.Worksheets(years(CStr(year))(1)).Copy before:=archive.Worksheets(1)
    archive.SaveAs CStr(filename), xlOpenXMLWorkbook
    message = "�N�x�V�[�g��ۊǂ��܂����B�����ȍX�V��͕ς��܂���B"
Finished:
    If Not archive Is Nothing Then archive.Close False
    If Not source Is Nothing Then source.Close False
    If Len(message) > 0 Then Notify message
    Exit Sub
Failed:
    message = "�ۊǌ��ʂ��m�F�ł��܂���B�ۑ�����J���Ċm�F���Ă��������B"
    Resume Finished
End Sub



