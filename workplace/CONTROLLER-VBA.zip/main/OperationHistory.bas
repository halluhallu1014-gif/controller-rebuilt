Attribute VB_Name = "OperationHistory"
Option Explicit
Option Private Module

Public Sub WriteHistory(ByVal recovery As Worksheet)
    Dim row As Long
    Dim operation As String
    Dim identity As String
    Dim transactionId As String
    operation = CStr(recovery.Range("B5").Value2)
    If Len(operation) = 0 Then Exit Sub
    identity = CStr(recovery.Range("B2").Value2) & "|" & CStr(recovery.Range("D4").Value2)
    transactionId = CStr(recovery.Range("D5").Value2)
    For row = 6 To LastRow(recovery)
        If recovery.Cells(row, 4).Value2 = "Yes" Then
            AppendHistory CStr(recovery.Range("B3").Value2), identity, operation, CStr(recovery.Cells(row, 1).Value2), _
                recovery.Cells(row, 3).Value2, recovery.Cells(row, 2).Value2, transactionId
        End If
    Next
End Sub

Public Sub AppendHistory(ByVal address As String, ByVal identity As String, ByVal operation As String, _
    ByVal fieldId As String, ByVal oldValue As Variant, ByVal newValue As Variant, ByVal transactionId As String)
    Dim history As Worksheet
    Dim output(1 To 1, 1 To 10) As Variant
    Dim row As Long
    Set history = Sheet("History")
    For row = LastRow(history) To 2 Step -1
        If history.Cells(row, 10).Value2 <> transactionId Then Exit For
        If history.Cells(row, 6).Value2 = fieldId Then Exit Sub
    Next
    output(1, 1) = Format$(Now, "yyyy/mm/dd hh:nn:ss")
    output(1, 2) = Application.UserName
    output(1, 3) = address
    output(1, 4) = identity
    output(1, 5) = operation
    output(1, 6) = fieldId
    output(1, 7) = oldValue
    output(1, 8) = newValue
    output(1, 9) = "�ۑ��m�F�ς�"
    output(1, 10) = transactionId
    With history.Cells(LastRow(history) + 1, 1).Resize(1, 10)
        .NumberFormat = "@"
        .Value2 = output
    End With
End Sub

Public Function NewTransactionId() As String
    NewTransactionId = Format$(Now, "yyyymmddhhnnss") & "-" & Format$(Timer * 1000, "00000000") & "-" & CStr(LastRow(Sheet("History")))
End Function

