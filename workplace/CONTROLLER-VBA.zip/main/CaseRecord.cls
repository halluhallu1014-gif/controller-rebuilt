VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "CaseRecord"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

Public sourceYear As String
Public sourceAddress As String
Public sourceSheet As String
Public sourceRow As Long
Public originalRow As Variant
Public sourceColumns As Object
Public values As Object
Public invalidReason As String
Public comparisonNumber As String

Private Sub Class_Initialize()
    Set values = CreateObject("Scripting.Dictionary")
End Sub

Public Property Get personKey() As String
    If values.Exists("CommonNumber") Then
        If IsDigits(values("CommonNumber"), 18) Then personKey = CStr(values("CommonNumber"))
    End If
End Property

Public Property Get caseIdentity() As String
    caseIdentity = personKey
End Property

Public Property Get key() As String
    Dim identity As String
    identity = caseIdentity
    If Len(identity) = 0 Then
        key = sourceYear & "|InvalidRow|" & CStr(sourceRow)
    Else
        key = sourceYear & "|" & identity
    End If
End Property
