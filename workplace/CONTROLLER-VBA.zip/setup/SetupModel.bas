Attribute VB_Name = "SetupModel"
Option Explicit

Public targetPath As String
Public draftYears As Object
Public fieldSpecs As Object
Public originalValues As Object
Public draftChanges As Object
Public comparisonPath As String
Public comparisonSheet As String

Public Function Dictionary() As Object
    Set Dictionary = CreateObject("Scripting.Dictionary")
End Function

Public Function Filesystem() As Object
    Set Filesystem = CreateObject("Scripting.FileSystemObject")
End Function

Public Function SheetLastRow(ByVal sheet As Worksheet, ByVal columns As String) As Long
    Dim found As Range
    Set found = sheet.Range(columns).Find(What:="*", after:=sheet.Range(columns).Cells(1, 1), LookIn:=xlFormulas, _
        LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, SearchFormat:=False)
    SheetLastRow = 1
    If Not found Is Nothing Then SheetLastRow = found.row
End Function

Public Function FileLabel(ByVal address As String) As String
    address = Replace(address, "\", "/")
    FileLabel = Mid$(address, InStrRev(address, "/") + 1)
End Function

Public Function IsWeb(ByVal address As String) As Boolean
    IsWeb = LCase$(Left$(address, 8)) = "https://"
End Function

Public Function IsDirectUrl(ByVal address As String) As Boolean
    IsDirectUrl = IsHttpsAddress(address) And Len(CanonicalAddress(address)) > 0
End Function

Public Function IsWorkbookUrl(ByVal address As String) As Boolean
    IsWorkbookUrl = IsHttpsAddress(address) And IsDirectWorkbookAddress(address)
End Function

Public Function IsSameAddress(ByVal first As String, ByVal second As String) As Boolean
    If IsWeb(first) Or IsWeb(second) Then
        IsSameAddress = IsSameWorkbookAddress(first, second)
    Else
        IsSameAddress = StrComp(first, second, vbTextCompare) = 0
    End If
End Function

Public Function SafeOpen(ByVal address As String, ByVal writableTarget As Boolean, ByRef message As String) As Workbook
    Set SafeOpen = OpenAddressWorkbook(address, Not writableTarget, writableTarget, message)
End Function

Public Function HeadersMatch(ByVal sheet As Worksheet, ByVal firstColumn As Long, ByVal expected As Variant) As Boolean
    Dim index As Long
    For index = LBound(expected) To UBound(expected)
        If CStr(sheet.Cells(1, firstColumn + index).Value2) <> CStr(expected(index)) Then Exit Function
    Next
    HeadersMatch = True
End Function

Public Function IsController(ByVal book As Workbook, ByRef message As String) As Boolean
    Dim settings As Worksheet
    Dim fields As Worksheet
    Dim comparison As Worksheet
    Dim other As Worksheet
    On Error GoTo Invalid
    If book.FileFormat <> xlOpenXMLWorkbookMacroEnabled Or book.Date1904 Then GoTo Invalid
    Set settings = book.Worksheets("Settings")
    Set fields = book.Worksheets("Fields")
    Set comparison = book.Worksheets("Comparison")
    Set other = book.Worksheets("����")
    Set other = book.Worksheets("�ڍ�")
    If Not HeadersMatch(settings, 1, Array("Setting", "Value")) Then GoTo Invalid
    If Not HeadersMatch(settings, 4, Array("Year", "�i���g�p�j", "Sheet", "Enabled", "AllowWrite", "�i���g�p�j")) Then GoTo Invalid
    If Not HeadersMatch(fields, 1, Array("FieldId", "Header", "Type", "Sheet", "Cell", "Required")) Then GoTo Invalid
    If Not HeadersMatch(fields, 8, Array("Year", "FieldId", "HeaderOverride")) Then GoTo Invalid
    If CStr(comparison.Range("A2").Value2) <> "Address" Or CStr(comparison.Range("A3").Value2) <> "Sheet" Then GoTo Invalid
    If CStr(book.Worksheets("Recovery").Range("B1").Value2) <> "" Or _
        CStr(book.Worksheets("MoveRecovery").Range("B1").Value2) <> "" Then
        message = "�{�̂őO��̕ۑ��E�ړ����ʂ��m�F���Ă���ݒ肵�Ă��������B"
        Exit Function
    End If
    IsController = True
    Exit Function
Invalid:
    message = "�Ή�����CONTROLLER�̐ݒ�\����������܂���B�����ł� .xlsm ��I�����Ă��������B"
End Function

Public Function Snapshot(ByVal book As Workbook) As Object
    Dim result As Object
    Dim sheetName As Variant
    Dim sheet As Worksheet
    Dim columnCount As Long
    Dim rowIndex As Long
    Dim colIndex As Long
    Dim area As Range
    Dim formulas As Variant
    Dim values As Variant
    Dim value As Variant
    Set result = Dictionary()
    For Each sheetName In Array("Settings", "Fields", "Comparison")
        Set sheet = book.Worksheets(CStr(sheetName))
        Select Case sheetName
            Case "Settings": columnCount = 25
            Case "Fields": columnCount = 11
            Case "Comparison": columnCount = 6
        End Select
        Set area = sheet.Range(sheet.Cells(1, 1), sheet.Cells(Application.Max(7, SheetLastRow(sheet, "A:" & _
            Split(sheet.Cells(1, columnCount).address, "$")(1))), columnCount))
        'Formula�͐��l�萔�𕶎���ŕԂ����Ƃ�����B�萔�̌^��Value2�ŕێ�����B
        formulas = area.Formula
        values = area.Value2
        For rowIndex = 1 To UBound(values, 1)
            For colIndex = 1 To columnCount
                value = values(rowIndex, colIndex)
                If VarType(formulas(rowIndex, colIndex)) = vbString Then
                    If Left$(formulas(rowIndex, colIndex), 1) = "=" Then
                        If area.Cells(rowIndex, colIndex).HasFormula Then value = formulas(rowIndex, colIndex)
                    End If
                End If
                If IsError(value) Then Err.Raise 5, , "�ݒ�V�[�g��Excel�G���[������܂��B"
                If Len(CStr(value)) > 0 Then
                    result.Add CStr(sheetName) & "|" & rowIndex & "|" & colIndex, value
                End If
            Next
        Next
    Next
    Set Snapshot = result
End Function

Public Function ReadCell(ByVal sheetName As String, ByVal row As Long, ByVal column As Long) As String
    Dim key As String
    key = sheetName & "|" & row & "|" & column
    If draftChanges.Exists(key) Then
        ReadCell = CStr(draftChanges(key))
    ElseIf originalValues.Exists(key) Then
        ReadCell = CStr(originalValues(key))
    End If
End Function

Public Sub StageCell(ByVal sheetName As String, ByVal row As Long, ByVal column As Long, ByVal value As String)
    Dim key As String
    Dim original As String
    key = sheetName & "|" & row & "|" & column
    If originalValues.Exists(key) Then original = CStr(originalValues(key))
    If value = original Then
        If draftChanges.Exists(key) Then draftChanges.Remove key
    Else
        draftChanges(key) = value
    End If
End Sub

Public Function ConfigRow(ByVal name As String) As Long
    Dim key As Variant
    Dim parts As Variant
    For Each key In originalValues.Keys
        parts = Split(CStr(key), "|")
        If parts(0) = "Settings" And parts(2) = "1" Then
            If originalValues(key) = name Then
                ConfigRow = CLng(parts(1))
                Exit Function
            End If
        End If
    Next
    Err.Raise 5, , "�K�v�ȉ^�p�ݒ肪�{�̂ɂ���܂���B"
End Function

Public Function IsDirty() As Boolean
    If Not draftChanges Is Nothing Then IsDirty = draftChanges.Count > 0
End Function

Public Function LoadTarget(ByVal address As String, ByRef message As String) As Boolean
    Dim book As Workbook
    Dim sheet As Worksheet
    Dim row As Long
    Dim fieldId As String
    Dim year As String
    Dim localYears As Object
    Dim localFields As Object
    Dim localValues As Object
    Dim item As Object
    On Error GoTo Failed
    message = ""
    Set book = SafeOpen(address, False, message)
    If book Is Nothing Then Exit Function
    If Not IsController(book, message) Then GoTo Finished
    Set localValues = Snapshot(book)
    Set localFields = Dictionary()
    Set localYears = Dictionary()
    Set sheet = book.Worksheets("Fields")
    For row = 2 To SheetLastRow(sheet, "A:A")
        fieldId = CStr(sheet.Cells(row, 1).Value2)
        If Len(fieldId) > 0 Then
            localFields.Add fieldId, Array(CStr(sheet.Cells(row, 2).Value2), _
                sheet.Cells(row, 6).Value2 = "Yes" Or fieldId = "CommonNumber", CStr(sheet.Cells(row, 3).Value2))
        End If
    Next
    If Not localFields.Exists("CommonNumber") Or Not localFields.Exists("PersonName") Then
        message = "�{�̂̕K�{���ڂ̒�`���s�����Ă��܂��B"
        GoTo Finished
    End If
    Set sheet = book.Worksheets("Settings")
    For row = 2 To SheetLastRow(sheet, "D:I")
        year = CStr(sheet.Cells(row, 4).Value2)
        If Len(year) > 0 Then
            If localYears.Exists(year) Then
                message = year & "�N�x���{�̂̐ݒ�ŏd�����Ă��܂��B�d���𐮗����Ă���J�������Ă��������B"
                GoTo Finished
            End If
            Set item = NewYearItem(row)
            item("Staff") = CStr(sheet.Range("B7").Value2)
            item("Sheet") = CStr(sheet.Cells(row, 6).Value2)
            item("Enabled") = (sheet.Cells(row, 7).Value2 = "Yes")
            item("Write") = CStr(sheet.Cells(row, 8).Value2)
            item("General") = CStr(sheet.Range("B8").Value2)
            localYears.Add year, item
        End If
    Next
    Set sheet = book.Worksheets("Comparison")
    comparisonPath = CStr(sheet.Range("B2").Value2)
    comparisonSheet = CStr(sheet.Range("B3").Value2)
    targetPath = book.FullName
    Set fieldSpecs = localFields
    Set draftYears = localYears
    Set originalValues = localValues
    Set draftChanges = Dictionary()
    LoadTarget = True
Finished:
    If Not book Is Nothing Then book.Close False
    Exit Function
Failed:
    message = "�����ݒ��ǂ߂܂���ł����B�`���E�d���E�����G���[���m�F���Ă��������B"
    Resume Finished
End Function

Public Function NewYearItem(ByVal row As Long) As Object
    Dim item As Object
    Set item = Dictionary()
    item.Add "Row", row
    item.Add "Staff", ""
    item.Add "General", ""
    item.Add "Sheet", ""
    item.Add "Enabled", False
    item.Add "Write", "No"
    item.Add "State", ""
    item.Add "Count", 0
    item.Add "Unmapped", ""
    Set NewYearItem = item
End Function

Public Function NextYearRow() As Long
    Dim year As Variant
    NextYearRow = 2
    For Each year In draftYears.Keys
        If draftYears(year)("Row") >= NextYearRow Then NextYearRow = draftYears(year)("Row") + 1
    Next
    Do While Len(ReadCell("Settings", NextYearRow, 5) & ReadCell("Settings", NextYearRow, 6) & _
        ReadCell("Settings", NextYearRow, 7) & ReadCell("Settings", NextYearRow, 8) & ReadCell("Settings", NextYearRow, 9)) > 0
        NextYearRow = NextYearRow + 1
    Loop
End Function

Public Function SetupAccount() As String
    If Len(Environ$("USERDOMAIN")) > 0 And Len(Environ$("USERNAME")) > 0 Then
        SetupAccount = Environ$("USERDOMAIN") & "\" & Environ$("USERNAME")
    End If
End Function

Public Function SetupOwnerAllowed(ByVal accounts As String) As Boolean
    Dim account As Variant
    If Len(SetupAccount()) = 0 Then Exit Function
    If Len(Trim$(accounts)) = 0 Then
        ' Initial setup also requires write access to the selected workbook.
        SetupOwnerAllowed = True
        Exit Function
    End If
    For Each account In Split(accounts, ";")
        If StrComp(Trim$(CStr(account)), SetupAccount(), vbTextCompare) = 0 Then
            SetupOwnerAllowed = True
            Exit Function
        End If
    Next
End Function

Public Function CanEditSetup(ByRef message As String) As Boolean
    Dim book As Workbook
    If Len(targetPath) = 0 Then Exit Function
    If Not SetupOwnerAllowed(ReadOriginalOwner()) Then
        message = "�ݒ�S���҂̃A�J�E���g�ŊJ���Ă��������B"
        Exit Function
    End If
    Set book = SafeOpen(targetPath, True, message)
    If book Is Nothing Then Exit Function
    CanEditSetup = SetupOwnerAllowed(CStr(book.Worksheets("Settings").Range("S2").Value2))
    book.Close False
    If Not CanEditSetup Then message = "�ݒ�S���҂̃A�J�E���g�ŊJ���Ă��������B"
End Function

Private Function ReadOriginalOwner() As String
    If originalValues.Exists("Settings|2|19") Then ReadOriginalOwner = CStr(originalValues("Settings|2|19"))
End Function

Public Function SetupFolderState(ByVal address As String) As String
    If Len(address) = 0 Then
        SetupFolderState = "���ݒ�"
    ElseIf Len(CanonicalAddress(address)) = 0 Then
        SetupFolderState = "�ꏊ������"
    ElseIf IsWeb(address) Then
        SetupFolderState = "�ڑ����m�F"
    ElseIf Filesystem().FolderExists(address) Then
        SetupFolderState = "�m�F�ς�"
    Else
        SetupFolderState = "�J���܂���"
    End If
End Function

Public Function SetupLedgerLocation(ByRef message As String, ByRef incomplete As Boolean) As String
    Dim staff As String, general As String, backup As String, fixed As String, alternate As String
    Dim first As String, second As String, files As Object
    Dim name As Variant, address As String, state As String
    Set files = Filesystem()
    staff = ReadCell("Settings", ConfigRow("StaffFolder"), 2)
    general = ReadCell("Settings", ConfigRow("GeneralFolder"), 2)
    backup = ReadCell("Settings", ConfigRow("BackupFolder"), 2)
    fixed = ReadCell("Settings", ConfigRow("StaffLedger"), 2)
    alternate = ReadCell("Settings", ConfigRow("GeneralLedger"), 2)
    If IsSingleLedgerSetup() Then
        SetupLedgerLocation = fixed
        Exit Function
    End If
    For Each name In Array("StaffFolder", "GeneralFolder", "BackupFolder")
        address = ReadCell("Settings", ConfigRow(CStr(name)), 2)
        state = SetupFolderState(address)
        Select Case state
            Case "���ݒ�": incomplete = True
            Case "�m�F�ς�", "�ڑ����m�F"
            Case Else
                message = SetupFolderLabel(CStr(name)) & "���J���܂���B�t�H���_��I�ђ����Ă��������B"
                Exit Function
        End Select
    Next
    If incomplete Then
        message = "���ݒ�̕K�{�t�H���_��I�����Ă��������B�r���ۑ����ł��܂��B"
        Exit Function
    End If
    If IsSameWorkbookAddress(staff, general) Or IsSameWorkbookAddress(staff, backup) Or _
        IsSameWorkbookAddress(general, backup) Then
        message = "��΁E���΁E�ޔ��ɂ́A���ꂼ��ʂ̃t�H���_��I�����Ă��������B"
        Exit Function
    End If
    If IsWeb(staff) <> IsWeb(general) Or IsWeb(staff) <> IsWeb(backup) Then
        message = "3�t�H���_�̎w������[�J���p�X��SharePoint����URL�ɂ��낦�Ă��������B"
        Exit Function
    End If
    If IsWeb(staff) Then
        incomplete = True
        message = "SharePoint�ւ̐ڑ��͖��m�F�ł��B�ۑ���A�{�̂́u�ŐV���ēǍ��v�Ŋm�F���Ă��������B"
        Exit Function
    End If
    first = files.BuildPath(staff, "�Ǘ���.xlsm")
    second = files.BuildPath(general, "�Ǘ���.xlsm")
    If files.FileExists(first) And files.FileExists(second) Then
        message = "��΂Ɣ��΂̗����ɊǗ��낪����܂��B�����ȊǗ���̏��݂��m�F���Ă��������B"
    ElseIf files.FileExists(first) Then
        SetupLedgerLocation = first
    ElseIf files.FileExists(second) Then
        SetupLedgerLocation = second
    ElseIf Len(fixed) > 0 And Not IsWeb(fixed) And files.FileExists(fixed) Then
        SetupLedgerLocation = fixed
    Else
        incomplete = True
        message = "��΁E���΂̂ǂ��炩����ɊǗ���.xlsm��z�u���Ă��������B"
    End If
End Function

Public Function IsSingleLedgerSetup() As Boolean
    Dim staff As String, general As String, fixed As String
    staff = ReadCell("Settings", ConfigRow("StaffFolder"), 2)
    general = ReadCell("Settings", ConfigRow("GeneralFolder"), 2)
    fixed = ReadCell("Settings", ConfigRow("StaffLedger"), 2)
    If Len(CanonicalAddress(staff)) > 0 And Len(CanonicalAddress(general)) > 0 Then
        If IsWeb(staff) = IsWeb(general) And Not IsSameWorkbookAddress(staff, general) Then Exit Function
    End If
    IsSingleLedgerSetup = IsDirectWorkbookAddress(fixed) And Not IsWeb(fixed) And _
        Len(ReadCell("Settings", ConfigRow("GeneralLedger"), 2)) = 0
End Function

Public Function SetupFolderLabel(ByVal key As String) As String
    Select Case key
        Case "StaffFolder": SetupFolderLabel = "��΃t�H���_�iStaff�j"
        Case "GeneralFolder": SetupFolderLabel = "���΃t�H���_�iGeneral�j"
        Case "BackupFolder": SetupFolderLabel = "�ޔ��t�H���_�iBackup�j"
    End Select
End Function

Public Function SetupReadiness(ByRef message As String, ByRef incomplete As Boolean) As Boolean
    Dim address As String, year As Variant, id As Variant, configured As String, detected As String
    Dim item As Object, table As Object
    Dim found As Boolean
    message = ""
    incomplete = False
    address = SetupLedgerLocation(message, incomplete)
    If Len(address) = 0 Then Exit Function
    If IsWeb(address) Then
        incomplete = True
        message = "SharePoint�ւ̐ڑ��͖��m�F�ł��B�ۑ���A�{�̂ŊǗ�����m�F���Ă��������B"
        Exit Function
    End If
    If draftYears.Count = 0 Then
        Set table = ReadTable(address, "", True, message, False)
        If table Is Nothing Then Exit Function
        detected = CStr(table("Year"))
        If Not IsYear(detected) Then
            incomplete = True
            message = "�Ǘ���̔N�x�����ł��܂���B�u�N�x���m�F�v�ŃV�[�g�ƔN�x��I�����Ă��������B"
            Exit Function
        End If
        If Not RequiredLedgerHeadings(detected, table("Headers"), message) Then Exit Function
    Else
        For Each year In draftYears.Keys
            Set item = draftYears(year)
            If item("Enabled") Then
                found = True
                configured = CStr(item("Sheet"))
                If Len(configured) = 0 Then
                    message = year & "�N�x�̃V�[�g���u���o���ƑΉ��v�őI�ђ����Ă��������B"
                    Exit Function
                End If
                Set table = ReadTable(address, configured, True, message, False)
                If table Is Nothing Then Exit Function
                If CStr(table("Sheet")) <> configured Then
                    message = year & "�N�x�̃V�[�g��������܂���B�u���o���ƑΉ��v�őI�ђ����Ă��������B"
                    Exit Function
                End If
                If Not RequiredLedgerHeadings(CStr(year), table("Headers"), message) Then Exit Function
            End If
        Next
        If Not found Then
            incomplete = True
            message = "�g�p����N�x���u�N�x���m�F�v�Œǉ����Ă��������B"
            Exit Function
        End If
    End If
    message = "�Ǘ���̔N�x�E�V�[�g�E�K�{���o�����m�F���܂����B�{�̂́u�ŐV���ēǍ��v�Ŏg�p���J�n�ł��܂��B"
    SetupReadiness = True
End Function




