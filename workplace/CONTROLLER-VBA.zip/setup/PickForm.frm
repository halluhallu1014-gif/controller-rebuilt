VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} PickForm 
   Caption         =   "�I��"
   ClientHeight    =   3570
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   9135.001
   OleObjectBlob   =   "PickForm.frx":0000
   StartUpPosition =   1  '�I�[�i�[ �t�H�[���̒���
End
Attribute VB_Name = "PickForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private result As String

Public Function Choose(ByVal message As String, ByVal options As Collection, ByVal current As String) As String
    Dim value As Variant
    Dim index As Long
    StyleControls Me
    prompt.Caption = message
    Choices.Clear
    For Each value In options
        Choices.AddItem CStr(value)
        If CStr(value) = current Then Choices.ListIndex = index
        index = index + 1
    Next
    If Choices.ListCount = 1 Then Choices.ListIndex = 0
    Me.Show
    Choose = result
End Function

Private Sub AcceptChoice_Click()
    If Choices.ListIndex < 0 Then Exit Sub
    result = CStr(Choices.value)
    Me.Hide
End Sub

Private Sub CancelChoice_Click()
    Me.Hide
End Sub

Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = vbFormControlMenu Then
        Cancel = True
        Me.Hide
    End If
End Sub
