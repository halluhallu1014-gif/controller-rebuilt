Attribute VB_Name = "LedgerSetup"
Option Explicit

Private Const ABSENT As String = "[Absent]"

Public Function FieldLabel(ByVal fieldId As String) As String
    If fieldId = "CommonNumber" Then
        FieldLabel = "���ʔԍ�"
    ElseIf fieldId = "SubmissionFormat" Then
        FieldLabel = "��o�`��"
    ElseIf fieldId = "HistoryMemo" Then
        FieldLabel = "������������"
    ElseIf fieldId = "SourceYear" Then
        FieldLabel = "��t�N�x"
    Else
        FieldLabel = CStr(fieldSpecs(fieldId)(0))
        If FieldLabel = ABSENT Then FieldLabel = "���̑��̍���"
    End If
End Function

Private Function NormalHeader(ByVal heading As String) As String
    NormalHeader = Trim$(Replace(Replace(heading, ChrW(&H3000), " "), vbTab, " "))
End Function

Private Function AliasHeader(ByVal fieldId As String) As String
    Select Case fieldId
        Case "CommonNumber": AliasHeader = "CommonNumber"
        Case "Furigana": AliasHeader = "����(�t���K�i)"
        Case "SubmissionFormat": AliasHeader = "��o�`��"
    End Select
End Function

Private Function UniqueHeading(ByVal headers As Object, ByVal heading As String) As String
    Dim key As Variant
    If Len(heading) = 0 Or heading = ABSENT Then Exit Function
    If headers.Exists(heading) Then
        UniqueHeading = heading
        Exit Function
    End If
    For Each key In headers.Keys
        If NormalHeader(CStr(key)) = NormalHeader(heading) Then
            If Len(UniqueHeading) > 0 Then
                UniqueHeading = ""
                Exit Function
            End If
            UniqueHeading = CStr(key)
        End If
    Next
End Function

Private Function HeaderList(ByVal sheet As Worksheet, ByRef message As String) As Object
    Dim result As Object
    Dim last As Range
    Dim index As Long
    Dim value As Variant
    Set result = Dictionary()
    Set last = sheet.rows(1).Find(What:="*", after:=sheet.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, _
        SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False, SearchFormat:=False)
    If last Is Nothing Then
        message = sheet.name & " ��1�s�ڂɌ��o��������܂���B"
        Exit Function
    End If
    For index = 1 To last.column
        value = sheet.Cells(1, index).Value2
        If IsError(value) Then
            message = sheet.name & " ��1�s�ڂ�Excel�G���[������܂��B"
            Exit Function
        End If
        If Len(CStr(value)) > 0 Then
            If result.Exists(CStr(value)) Then
                message = sheet.name & " �̌��o���u" & CStr(value) & "�v���d�����Ă��܂��B"
                Exit Function
            End If
            result.Add CStr(value), index
        End If
    Next
    If result.Count < 2 Then
        message = sheet.name & " ��1�s�ڂɕ����̌��o�����K�v�ł��B"
        Exit Function
    End If
    Set HeaderList = result
End Function

Private Function LooksLikeLedger(ByVal headers As Object) As Boolean
    Dim id As Variant
    For Each id In Array("CommonNumber", "PersonName")
        If Len(UniqueHeading(headers, CStr(fieldSpecs(id)(0)))) = 0 Then
            If Len(UniqueHeading(headers, AliasHeader(CStr(id)))) = 0 Then Exit Function
        End If
    Next
    LooksLikeLedger = True
End Function

Public Function ReadTable(ByVal address As String, ByVal preferredSheet As String, ByVal isLedger As Boolean, ByRef message As String) As Object
    Dim book As Workbook
    Dim sheet As Worksheet
    Dim selected As Worksheet
    Dim headerMap As Object
    Dim result As Object
    Dim plausible As New Collection
    Dim names As New Collection
    Dim name As Variant
    Dim ignore As String
    On Error GoTo Failed
    message = ""
    If IsWeb(address) And Not IsWorkbookUrl(address) Then
        message = "���L�����N�ł͂Ȃ��A�g���q�܂ł̒���URL����͂��Ă��������B"
        Exit Function
    End If
    If IsSameAddress(address, targetPath) Or IsSameAddress(address, ThisWorkbook.FullName) Then
        message = "�ݒ�u�b�N�Ɩ{�̂͊Ǘ���Ƃ��đI�ׂ܂���B"
        Exit Function
    End If
    Set book = SafeOpen(address, False, message)
    If book Is Nothing Then Exit Function
    If book.Date1904 Then
        message = "1904�N���t�`���̃t�@�C���͖{�̂œǂݍ��߂܂���B"
        GoTo Finished
    End If
    For Each sheet In book.Worksheets
        names.Add sheet.name
        If sheet.name = preferredSheet Then Set selected = sheet
        ignore = ""
        Set headerMap = HeaderList(sheet, ignore)
        If Not headerMap Is Nothing Then
            If Not isLedger Or LooksLikeLedger(headerMap) Then plausible.Add sheet.name
        End If
    Next
    If selected Is Nothing Then
        If names.Count = 1 Then
            Set selected = book.Worksheets(CStr(names(1)))
        ElseIf plausible.Count = 1 Then
            Set selected = book.Worksheets(CStr(plausible(1)))
        Else
            If plausible.Count > 1 Then Set names = plausible
            name = PickValue("�ǂݍ��ރV�[�g��I�����Ă��������B", names)
            If Len(CStr(name)) = 0 Then GoTo Finished
            Set selected = book.Worksheets(CStr(name))
        End If
    End If
    Set headerMap = HeaderList(selected, message)
    If headerMap Is Nothing Then GoTo Finished
    Set result = Dictionary()

    result.Add "Address", book.FullName
    result.Add "Year", DetectLedgerYear(selected.name, book.name)
    result.Add "Columns", selected.Cells(1, selected.columns.Count).End(xlToLeft).column
    result.Add "Sheet", selected.name
    result.Add "Headers", headerMap
    result.Add "Count", SheetLastRow(selected, "A:XFD") - 1
    Set ReadTable = result
Finished:
    If Not book Is Nothing Then book.Close False
    Exit Function
Failed:
    message = FileLabel(address) & " �̃V�[�g�܂��͌��o����ǂݎ��܂���B"
    Resume Finished
End Function



Public Function IsYear(ByVal value As String) As Boolean
    IsYear = Len(value) = 4 And value Like "####"
    If IsYear Then IsYear = CLng(value) >= 1900 And CLng(value) <= 2099
End Function























Public Sub StageDisable(ByVal year As String)
    StageCell "Settings", CLng(draftYears(year)("Row")), 7, "No"
    draftYears(year)("Enabled") = False
    draftYears(year)("State") = "�����E�ۑ��҂�"
End Sub


Public Sub CheckLedgerHeadings(ByVal year As String, ByVal headers As Object, ByVal review As Boolean, ByVal item As Object)
    Dim id As Variant
    Dim key As Variant
    Dim heading As String
    Dim picked As String
    Dim row As Long
    Dim rows As Object
    Dim used As Object
    Dim missing As Object
    Dim options As Collection
    Set rows = Dictionary()
    Set used = Dictionary()
    Set missing = Dictionary()
    For Each id In fieldSpecs.Keys
        row = LedgerHeadingRow(year, CStr(id))
        heading = CStr(fieldSpecs(id)(0))
        If row > 0 Then heading = ReadCell("Fields", row, 10)
        heading = UniqueHeading(headers, heading)
        If Len(heading) = 0 And row = 0 Then
            heading = UniqueHeading(headers, AliasHeader(CStr(id)))
            If Len(heading) > 0 Then SaveLedgerHeading year, CStr(id), heading, row
        End If
        If Len(heading) > 0 And Not used.Exists(heading) Then
            used.Add heading, True
        ElseIf fieldSpecs(id)(0) <> ABSENT Or row > 0 Then
            rows.Add id, row
            missing.Add id, FieldLabel(CStr(id))
        End If
    Next
    item("Unmapped") = ""
    For Each id In missing.Keys
        If review Then
            Set options = New Collection
            For Each key In headers.Keys
                If Not used.Exists(key) Then options.Add CStr(key)
            Next
            picked = PickValue("�Ǘ���Łu" & missing(id) & "�v�ɓ����錩�o����I��ł��������B", options)
            If Len(picked) > 0 Then
                SaveLedgerHeading year, CStr(id), picked, CLng(rows(id))
                used.Add picked, True
            End If
        Else
            picked = ""
        End If
        If Len(picked) = 0 Then
            If Len(item("Unmapped")) > 0 Then item("Unmapped") = item("Unmapped") & "�A"
            item("Unmapped") = item("Unmapped") & missing(id)
        End If
    Next
End Sub

Private Function LedgerHeadingRow(ByVal year As String, ByVal fieldId As String) As Long
    Dim row As Long
    row = 2
    Do While Len(ReadCell("Fields", row, 8) & ReadCell("Fields", row, 9)) > 0
        If ReadCell("Fields", row, 8) = year And ReadCell("Fields", row, 9) = fieldId Then
            LedgerHeadingRow = row
            Exit Function
        End If
        row = row + 1
    Loop
End Function

Private Sub SaveLedgerHeading(ByVal year As String, ByVal fieldId As String, ByVal heading As String, ByVal existingRow As Long)
    Dim row As Long
    row = existingRow
    If row = 0 Then
        row = 2
        Do While Len(ReadCell("Fields", row, 8) & ReadCell("Fields", row, 9) & ReadCell("Fields", row, 10)) > 0
            row = row + 1
        Loop
    End If
    StageCell "Fields", row, 8, year
    StageCell "Fields", row, 9, fieldId
    StageCell "Fields", row, 10, heading
End Sub

Private Function DetectLedgerYear(ByVal sheetName As String, ByVal filename As String) As String
    Dim source As Variant
    Dim index As Long
    Dim candidate As String
    Dim years As Object
    If IsYear(sheetName) Then
        DetectLedgerYear = sheetName
        Exit Function
    End If
    Set years = Dictionary()
    For Each source In Array(sheetName, filename)
        For index = 1 To Len(CStr(source)) - 3
            candidate = Mid$(CStr(source), index, 4)
            If IsYear(candidate) Then
                If Not Mid$(" " & CStr(source), index, 1) Like "#" And _
                    Not Mid$(CStr(source) & " ", index + 4, 1) Like "#" Then years(candidate) = True
            End If
        Next
    Next
    If years.Count = 1 Then DetectLedgerYear = CStr(years.Keys()(0))
End Function


