Attribute VB_Name = "SetupActions"
Option Explicit

Public Sub OpenSetup()
    SettingsForm.Show
End Sub

Public Sub StyleControls(ByVal form As Object)
    Dim control As Object
    For Each control In form.Controls
        control.Font.name = "Meiryo UI"
        control.Font.Size = 10
    Next
End Sub

Public Function PickValue(ByVal prompt As String, ByVal values As Collection, Optional ByVal current As String = "") As String
    Dim picker As New PickForm
    PickValue = picker.Choose(prompt, values, current)
    Unload picker
End Function

Public Function Choices(ParamArray values() As Variant) As Collection
    Dim result As New Collection
    Dim value As Variant
    For Each value In values
        result.Add CStr(value)
    Next
    Set Choices = result
End Function

Public Function SelectFiles(ByVal title As String, ByVal controllerOnly As Boolean, ByVal multiple As Boolean) As Collection
    Dim dialog As Object
    Dim result As New Collection
    Dim item As Variant
    On Error GoTo Finished
    Set dialog = Application.FileDialog(3)
    With dialog
        .title = title
        .AllowMultiSelect = multiple

        If Len(targetPath) > 0 And Not IsWeb(targetPath) Then
            .InitialFileName = AddressFolder(targetPath) & "\"
        ElseIf Not IsWeb(ThisWorkbook.FullName) Then
            .InitialFileName = ThisWorkbook.path & "\"
        End If
        .Filters.Clear
        If controllerOnly Then
            .Filters.Add "CONTROLLER", "*.xlsm"
        Else
            .Filters.Add "Excel�t�@�C��", "*.xlsx;*.xlsm;*.xlsb;*.xls"
        End If
        If .Show = -1 Then
            For Each item In .SelectedItems
                result.Add CStr(item)
            Next
        End If
    End With
Finished:
    Set SelectFiles = result
End Function

Public Function SelectFolder(ByVal title As String) As String
    Dim dialog As Object
    On Error GoTo Finished
    Set dialog = Application.FileDialog(4)
    dialog.title = title
    dialog.AllowMultiSelect = False
    If dialog.Show = -1 Then SelectFolder = CStr(dialog.SelectedItems(1))
Finished:
End Function


Public Function ChooseAddress(ByVal title As String, ByVal current As String, ByVal folder As Boolean, _
    Optional ByVal controllerOnly As Boolean = False) As Variant
    Dim selection As Collection
    Dim picked As String
    Dim answer As Variant
    Dim choice As VbMsgBoxResult
    ChooseAddress = False
    If folder Then
        picked = SelectFolder(title)
    Else
        Set selection = SelectFiles(title, controllerOnly, False)
        If selection.Count > 0 Then picked = CStr(selection(1))
    End If
    If Len(picked) > 0 Then
        If IsWeb(current) And Not IsWeb(picked) Then
            choice = MsgBox("�I�����ʂ̓��[�J���p�X�ł��B���̃p�X���g�p���܂����H" & vbCrLf & _
                "�u�������v�Œ���URL����͂ł��܂��B", vbYesNoCancel Or vbQuestion)
            If choice = vbCancel Then Exit Function
            If choice = vbYes Then
                ChooseAddress = picked
                Exit Function
            End If
        Else
            ChooseAddress = picked
            Exit Function
        End If
    End If
    ChooseAddress = False
    If MsgBox(title & "�F�I���ł��Ȃ��ꍇ�͐�΃p�X�܂��͒���URL����͂ł��܂��B���͂��܂����H", _
        vbYesNo Or vbQuestion Or vbDefaultButton2) <> vbYes Then Exit Function
    answer = AskText(title & "�̐�΃p�X�܂��͒���URL����͂��Ă��������B", current)
    If VarType(answer) = vbBoolean Then Exit Function
    picked = Trim$(CStr(answer))
    If Len(picked) = 0 Then Exit Function
    If folder Then
        If Len(CanonicalAddress(picked)) = 0 Then GoTo InvalidAddress
    ElseIf Not IsDirectWorkbookAddress(picked) Then
        GoTo InvalidAddress
    End If
    ChooseAddress = picked
    Exit Function
InvalidAddress:
    MsgBox "��΃p�X�܂��͋��L�����N�ł͂Ȃ�����URL���w�肵�Ă��������B", vbExclamation
End Function

Public Function AskText(ByVal prompt As String, Optional ByVal current As String = "") As Variant
    AskText = Application.InputBox(prompt, "CONTROLLER �ݒ�", current, Type:=2)
End Function









Public Function PrepareComparison(ByVal address As String, ByRef message As String, ByVal review As Boolean) As Boolean
    Dim table As Object
    Dim existing As Object
    Dim configured As Object
    Dim headers As Object
    Dim yearKeys As Variant
    Dim key As Variant
    Dim row As Long
    Dim id As String
    Dim heading As String
    Dim picked As String
    Dim values As New Collection
    Dim labels As Object
    Set table = ReadTable(address, comparisonSheet, False, message)

    If table Is Nothing Then
        If Len(message) > 0 Then message = message & vbCrLf & "�w�肵���A�h���X�͓r���ۑ��ł��܂��B"
        Exit Function
    End If
    If comparisonSheet <> CStr(table("Sheet")) Then StageCell "Comparison", 4, 2, "No"
    comparisonSheet = CStr(table("Sheet"))
    StageCell "Comparison", 3, 2, comparisonSheet
    Set headers = table("Headers")
    Set existing = Dictionary()
    Set configured = Dictionary()
    For row = 8 To LastComparisonRow()
        id = ReadCell("Comparison", row, 1)
        If Len(id) > 0 Then
            heading = ReadCell("Comparison", row, 2)
            existing.Add id, Array(heading, ReadCell("Comparison", row, 3), ReadCell("Comparison", row, 4), ReadCell("Comparison", row, 5))
        End If
    Next
    For Each key In existing.Keys
        heading = CStr(existing(key)(0))

        If Not headers.Exists(heading) Then
            message = "�u" & FieldLabel(CStr(key)) & "�v�̌��o�����u�Ή����m�F�v�Ŏw�肵�Ă��������B"
            If Not review Then Exit Function
            heading = SelectExternalHeading(CStr(key), headers, configured)
        End If
        If Len(heading) = 0 Then Exit Function
        configured.Add CStr(key), Array(heading, existing(key)(1), existing(key)(2), existing(key)(3))
    Next

    If configured.Count = 0 Then
        If Not review Then
            message = "�V�[�g�u" & comparisonSheet & "�v���m�F���܂����B�ƍ��Ɏg�����ڂ́u�Ή����m�F�v�Ŏw��ł��܂��B"
            Exit Function
        End If
        yearKeys = Array("SourceYear", "CommonNumber")
        For Each key In yearKeys
            heading = SelectExternalHeading(CStr(key), headers, configured)
            If Len(heading) = 0 Then Exit Function
            configured.Add CStr(key), Array(heading, "Yes", "No", "")
        Next
        Set labels = Dictionary()
        For Each key In fieldSpecs.Keys
            If Not configured.Exists(key) Then
                id = FieldLabel(CStr(key))
                If Not labels.Exists(id) Then
                    labels.Add id, CStr(key)
                    values.Add id
                End If
            End If
        Next
        picked = PickValue("�ŏ��ɔ�r����Ǘ���̍��ڂ�I��ł��������B", values)
        If Len(picked) = 0 Then Exit Function
        id = CStr(labels(picked))
        heading = SelectExternalHeading(id, headers, configured)
        If Len(heading) = 0 Then Exit Function
        configured.Add id, Array(heading, "No", "No", "")
    End If
    PrepareComparison = StageComparison(table, configured, message)
    If PrepareComparison Then message = "�V�[�g�Əƍ��p�̌��o�����m�F���܂����B"
End Function

Private Function SelectExternalHeading(ByVal fieldId As String, ByVal headers As Object, ByVal configured As Object) As String
    Dim items As New Collection
    Dim heading As Variant
    Dim id As Variant
    Dim used As Boolean
    For Each heading In headers.Keys
        used = False
        For Each id In configured.Keys
            If configured(id)(0) = heading Then used = True
        Next
        If Not used Then items.Add CStr(heading)
    Next
    SelectExternalHeading = PickValue("������Łu" & FieldLabel(fieldId) & "�v�ɓ����錩�o����I��ł��������B", items)
End Function

Public Function LastComparisonRow() As Long
    Dim key As Variant
    Dim parts As Variant
    LastComparisonRow = 7
    For Each key In originalValues.Keys
        parts = Split(CStr(key), "|")
        If parts(0) = "Comparison" And CLng(parts(1)) > LastComparisonRow Then LastComparisonRow = CLng(parts(1))
    Next
    For Each key In draftChanges.Keys
        parts = Split(CStr(key), "|")
        If parts(0) = "Comparison" And CLng(parts(1)) > LastComparisonRow Then LastComparisonRow = CLng(parts(1))
    Next
End Function

Public Function StageComparison(ByVal table As Object, ByVal rules As Object, ByRef message As String) As Boolean
    Dim headers As Object
    Dim used As Object
    Dim id As Variant
    Dim row As Long
    Dim nextRow As Long
    Dim column As Long
    Dim keyCount As Long
    Dim compareCount As Long
    Set headers = table("Headers")
    Set used = Dictionary()
    For Each id In rules.Keys
        If Not headers.Exists(rules(id)(0)) Or used.Exists(rules(id)(0)) Then
            message = "������̌��o����������Ȃ����A�����̍��ڂɎg���Ă��܂��B"
            Exit Function
        End If
        used.Add rules(id)(0), True
        If rules(id)(1) = "Yes" Then
            keyCount = keyCount + 1
        Else
            compareCount = compareCount + 1
        End If
    Next
    If keyCount = 0 Or compareCount = 0 Then
        message = "�ƍ��Ɏg�����ʍ��ڂƁA��r���鍀�ڂ��w�肵�Ă��������B"
        Exit Function
    End If
    nextRow = LastComparisonRow() + 1
    For Each id In rules.Keys
        For row = 8 To LastComparisonRow()
            If ReadCell("Comparison", row, 1) = CStr(id) Then Exit For
        Next
        If row > LastComparisonRow() Then
            row = nextRow
            nextRow = nextRow + 1
        End If
        StageCell "Comparison", row, 1, CStr(id)
        For column = 2 To 5
            StageCell "Comparison", row, column, CStr(rules(id)(column - 2))
        Next
    Next
    If Not IsSameAddress(comparisonPath, CStr(table("Address"))) Or comparisonSheet <> CStr(table("Sheet")) Then
        StageCell "Comparison", 4, 2, "No"
    End If
    comparisonPath = CStr(table("Address"))
    comparisonSheet = CStr(table("Sheet"))
    StageCell "Comparison", 2, 2, comparisonPath
    StageCell "Comparison", 3, 2, comparisonSheet
    StageComparison = True
End Function

