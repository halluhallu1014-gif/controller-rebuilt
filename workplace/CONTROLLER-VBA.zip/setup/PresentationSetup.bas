Attribute VB_Name = "PresentationSetup"
Option Explicit

Public Function SupportsPresentation() As Boolean
    SupportsPresentation = (ReadCell("Fields", 1, 11) = "DisplayFormat" And ReadCell("Settings", 1, 16) = "������")
End Function

Public Function DraftChoices(ByVal column As Long) As Collection
    Dim result As New Collection
    Dim row As Long
    Dim value As String
    For row = 2 To 501
        value = ReadCell("Settings", row, column)
        If Len(value) > 0 Then result.Add value
    Next
    Set DraftChoices = result
End Function

Public Function StageChoices(ByVal column As Long, ByVal items As Collection, ByRef message As String) As Boolean
    Dim seen As Object
    Dim item As Variant
    Dim value As String
    Dim index As Long
    message = ""
    If Not SupportsPresentation() Or column < 16 Or column > 18 Then Exit Function
    If items.Count > 500 Then
        message = "�I������500���܂łł��B"
        Exit Function
    End If
    Set seen = Dictionary()
    seen.CompareMode = vbTextCompare
    For Each item In items
        value = Trim$(CStr(item))
        If Len(value) = 0 Or Len(value) > 255 Or seen.Exists(value) Or InStr(value, vbCr) > 0 Or InStr(value, vbLf) > 0 Then
            message = "�I�����ɂ͏d���̂Ȃ�255�����ȓ��̒l����͂��Ă��������B"
            Exit Function
        End If
        seen.Add value, True
    Next
    index = 2
    For Each item In items
        StageCell "Settings", index, column, Trim$(CStr(item))
        index = index + 1
    Next
    For index = index To 501
        StageCell "Settings", index, column, ""
    Next
    StageChoices = True
End Function

Public Function FormatChoices(ByVal id As String, ByVal fieldType As String) As Object
    Dim result As Object
    Set result = Dictionary()
    result.Add "�W���i�����j", ""
    If fieldType = "Date" Then
        result.Add "���t  yyyy/mm/dd", "dateSlash"
        result.Add "���t  yyyy-mm-dd", "dateDash"
        result.Add "���t  yyyy�Nm��d��", "dateJapanese"
    ElseIf fieldType = "Text" Then
        result.Add "������i�擪�[���ێ��j", "text"
        Select Case id
            Case "PostalCode", "PhoneNumber": result.Add "�����̂܂܁i�n�C�t���Ȃ��j", "digits"
            Case "TaxYear"
                result.Add "4���\���i�����̔N���̂݁j", "year4"
                result.Add "�����\���i�����̔N���̂݁j", "integer"
        End Select
    End If
    Set FormatChoices = result
End Function

Public Function StageDisplayFormat(ByVal id As String, ByVal preset As String) As Boolean
    Dim row As Long
    Dim Choices As Object
    Dim label As Variant
    If Not SupportsPresentation() Or id = "HistoryMemo" Or Len(id) = 0 Then Exit Function
    For row = 2 To 500
        If ReadCell("Fields", row, 1) = id Then
            Set Choices = FormatChoices(id, ReadCell("Fields", row, 3))
            For Each label In Choices.Keys
                If Choices(label) = preset Then
                    StageCell "Fields", row, 11, preset
                    StageDisplayFormat = True
                    Exit Function
                End If
            Next
            Exit Function
        End If
    Next
End Function

Private Function DictionaryLabels(ByVal Dictionary As Object) As Collection
    Dim result As New Collection
    Dim label As Variant
    For Each label In Dictionary.Keys
        result.Add CStr(label)
    Next
    Set DictionaryLabels = result
End Function

Public Sub EditDisplayFormat()
    Dim ids As Object
    Dim Choices As Object
    Dim row As Long
    Dim id As String
    Dim label As String
    Dim selected As String
    Dim current As String
    Set ids = Dictionary()
    For row = 2 To 500
        id = ReadCell("Fields", row, 1)
        If Len(id) > 0 And id <> "HistoryMemo" Then ids.Add FieldLabel(id), row
    Next
    selected = PickValue("�\���`����ݒ肷�鍀�ڂ�I�����Ă��������B", DictionaryLabels(ids))
    If Len(selected) = 0 Then Exit Sub
    row = ids(selected)
    id = ReadCell("Fields", row, 1)
    Set Choices = FormatChoices(id, ReadCell("Fields", row, 3))
    current = "�W���i�����j"
    Dim key As Variant
    For Each key In Choices.Keys
        If Choices(key) = ReadCell("Fields", row, 11) Then current = CStr(key)
    Next
    label = PickValue(selected & " �^ ���� " & current & vbCrLf & "�Ǘ���̕ۑ��^�͕ς��܂���B", DictionaryLabels(Choices), current)
    If Len(label) > 0 Then StageDisplayFormat id, CStr(Choices(label))
End Sub



